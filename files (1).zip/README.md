# EUR/USD Trading Alert Bot — Version 1

> **⚠️ IMPORTANT: This bot NEVER executes trades. It analyzes setups and sends alerts only. All trade decisions are made by you.**

---

## Project Structure

```
eurusd_alert_bot/
├── main.py           ← Entry point, main loop
├── config.py         ← All thresholds and settings (tweak here)
├── data_feed.py      ← Candle ingestion (simulation + live)
├── indicators.py     ← EMA, trend direction, candle types
├── structure.py      ← Swing detection, BOS, retest logic
├── zones.py          ← Supply/demand zones, liquidity sweeps
├── sessions.py       ← London/NY session tracking
├── news_filter.py    ← High-impact news calendar filter
├── scoring.py        ← Setup evaluation and confidence scoring
├── alerts.py         ← Alert formatting and delivery
├── journal.py        ← SQLite trade log
├── logger.py         ← Logging configuration
├── requirements.txt
├── .env.example
└── README.md
```

---

## Setup Instructions

### 1. Install Dependencies

```bash
cd eurusd_alert_bot
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your API keys (optional for simulation)
```

### 3. Run in Simulation Mode (default)

```bash
# Single analysis cycle
python main.py --mode once --verbose

# Continuous loop (scans every 60 seconds)
python main.py --mode run

# View journal stats
python main.py --mode stats
```

### 4. Switch to Live Data

1. Get a free Alpha Vantage API key at https://www.alphavantage.co/
2. Add it to `.env`: `ALPHA_VANTAGE_API_KEY=your_key`
3. In `config.py`: set `SIMULATION_MODE = False`

### 5. Configure Telegram Alerts

1. Create a bot via @BotFather → copy the token
2. Get your chat ID via @userinfobot
3. Add to `.env`, then in `config.py`: `ALERT_CHANNELS = ["console", "telegram"]`

---

## Key Settings to Tune (`config.py`)

| Setting | Default | Description |
|---------|---------|-------------|
| `MIN_ALERT_SCORE` | 70 | Minimum score to send alert |
| `MIN_RR` | 1.8 | Minimum risk:reward ratio |
| `PREFERRED_RR` | 2.0 | RR for bonus score points |
| `SWING_LOOKBACK` | 5 | Candles each side for swing detection |
| `SWEEP_TOLERANCE_PIPS` | 3 | How far below swing = valid sweep |
| `SCAN_INTERVAL_SECONDS` | 60 | How often to run analysis |
| `NEWS_BLOCK_BEFORE_MIN` | 15 | Block alerts before news (minutes) |

---

## Sample Alert Output

```
╔══════════════════════════════════════════════╗
  EUR/USD ALERT — BUY SETUP
╚══════════════════════════════════════════════╝

  Bias:        Bullish
  Confidence:  82/100  [████████░░]
  Session:     London
  Setup Type:  Liquidity Sweep Reversal
  Time (UTC):  2024-11-15 09:14

──────────────────────────────────────────────
  REASON
──────────────────────────────────────────────
  • 4H and 1H both bullish — timeframe alignment confirmed
  • Price reacting at 1H demand (1.08142–1.08210)
  • Liquidity sweep of recent swing detected (12.4 pip rejection wick)
  • 15M break of structure above 1.08185
  • Active London session

──────────────────────────────────────────────
  LEVELS
──────────────────────────────────────────────
  Entry Zone:  1.08230 – 1.08260
  Stop Loss:   1.08105
  TP1:         1.08420
  TP2:         1.08650
  RR:          1:2.1

──────────────────────────────────────────────
  INVALIDATION
──────────────────────────────────────────────
  • Price closes below 1.08105 (stop level)
  • Bearish BOS on 15M without recovery
  • Zone 1.08142 broken to the downside

──────────────────────────────────────────────
  TRADE QUALITY:  B-GRADE
──────────────────────────────────────────────
```

---

## Strategy Summary

The bot follows a 7-step discretionary framework:

1. **Higher Timeframe Bias** — 4H + 1H structure alignment
2. **Key Zone Reaction** — Supply/demand zones, PDH/PDL, session levels
3. **Liquidity Sweep** — Price traps one side before reversing
4. **Break of Structure** — Confirmation of direction change
5. **Retest** — Level holds after being broken
6. **Risk:Reward Filter** — Minimum 1.8R, prefer 2.0R
7. **News/Session Filter** — London & NY prime windows only

Alerts only fire when score ≥ 70/100:
- **A-grade (85–100):** High conviction — all criteria met
- **B-grade (70–84):** Good setup — minor conditions missing
- **Below 70:** No alert sent

---

## Suggested Version 2 Upgrades

- [ ] Add FVG (Fair Value Gap) detection on 5M/15M
- [ ] Add order block identification
- [ ] Multi-pair support (GBP/USD, USD/JPY)
- [ ] Backtesting against historical data
- [ ] Web dashboard (FastAPI + React) to view alerts
- [ ] Telegram inline buttons to manually log outcomes
- [ ] Machine learning score calibration from journal outcomes
- [ ] Discord rich embeds with price charts
- [ ] Real-time broker data integration (Interactive Brokers, OANDA)
- [ ] Alert deduplication (don't re-alert same setup)
- [ ] Weekly performance email report
