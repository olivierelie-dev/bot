"""
scoring.py — Setup scoring, RR calculation, and setup detection.
Orchestrates all strategy conditions and produces a scored setup object.
"""

import pandas as pd
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Optional
import config
import indicators as ind
import structure as st
import zones as z
import sessions as sess
import news_filter as nf


# ──────────────────────────────────────────────
# SETUP DATA STRUCTURE
# ──────────────────────────────────────────────

@dataclass
class Setup:
    direction: str               # 'buy' or 'sell'
    setup_type: str              # 'liquidity_sweep', 'break_retest', 'session_expansion'
    bias: str                    # 'bullish', 'bearish', 'neutral'
    session: str                 # 'london', 'new_york', 'overlap', etc.

    # Price levels
    entry_low: float = 0.0
    entry_high: float = 0.0
    stop_loss: float = 0.0
    tp1: float = 0.0
    tp2: float = 0.0
    rr: float = 0.0

    # Score breakdown
    score: int = 0
    score_breakdown: dict = field(default_factory=dict)
    grade: str = "No trade"

    # Reasoning
    reasons: list[str] = field(default_factory=list)
    invalidation_conditions: list[str] = field(default_factory=list)

    # Meta
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    news_status: dict = field(default_factory=dict)
    is_valid: bool = False

    def entry_midpoint(self) -> float:
        return (self.entry_low + self.entry_high) / 2


# ──────────────────────────────────────────────
# RISK / REWARD CALCULATOR
# ──────────────────────────────────────────────

def calculate_rr(entry: float, stop: float,
                 tp: float) -> float:
    """Calculate Risk:Reward ratio."""
    risk = abs(entry - stop)
    reward = abs(tp - entry)
    if risk == 0:
        return 0.0
    return round(reward / risk, 2)


def calculate_stop_and_tps(direction: str, entry: float,
                            sweep_level: float = None,
                            zone: z.Zone = None,
                            swings: dict = None,
                            nearby_structure: list = None) -> dict:
    """
    Calculate stop loss and take profit levels based on strategy rules.
    Returns: {"stop_loss", "tp1", "tp2", "stop_pips", "rr_tp1", "rr_tp2"}
    """
    result = {"stop_loss": 0.0, "tp1": 0.0, "tp2": 0.0,
              "stop_pips": 0.0, "rr_tp1": 0.0, "rr_tp2": 0.0}

    pip = config.PIP_SIZE
    buffer = 3 * pip  # 3-pip buffer beyond zone/sweep

    # ── Stop Loss ──
    if direction == "buy":
        if sweep_level is not None:
            sl = sweep_level - buffer
        elif zone is not None:
            sl = zone.bottom - buffer
        else:
            sl = entry - 20 * pip   # Default 20-pip stop

        stop_pips = (entry - sl) / pip

    else:  # sell
        if sweep_level is not None:
            sl = sweep_level + buffer
        elif zone is not None:
            sl = zone.top + buffer
        else:
            sl = entry + 20 * pip

        stop_pips = (sl - entry) / pip

    # Sanity check stop distance
    if stop_pips < config.MIN_STOP_PIPS:
        sl = (entry - config.MIN_STOP_PIPS * pip) if direction == "buy" else (entry + config.MIN_STOP_PIPS * pip)
        stop_pips = config.MIN_STOP_PIPS
    elif stop_pips > config.MAX_STOP_PIPS:
        return result  # Unrealistic stop — reject

    # ── Take Profits ──
    risk_dist = stop_pips * pip

    if direction == "buy":
        tp1 = entry + risk_dist * 1.5   # 1.5R
        tp2 = entry + risk_dist * 2.5   # 2.5R
        # If we have swing levels, snap TP to nearest structure
        if swings and swings.get("latest_swing_high"):
            sh = swings["latest_swing_high"]
            if sh > entry + risk_dist * 1.2:
                tp1 = sh - 2 * pip
                tp2 = sh + risk_dist * 1.0
    else:
        tp1 = entry - risk_dist * 1.5
        tp2 = entry - risk_dist * 2.5
        if swings and swings.get("latest_swing_low"):
            sl_level = swings["latest_swing_low"]
            if sl_level < entry - risk_dist * 1.2:
                tp1 = sl_level + 2 * pip
                tp2 = sl_level - risk_dist * 1.0

    result["stop_loss"] = round(sl, 5)
    result["tp1"] = round(tp1, 5)
    result["tp2"] = round(tp2, 5)
    result["stop_pips"] = round(stop_pips, 1)
    result["rr_tp1"] = calculate_rr(entry, sl, tp1)
    result["rr_tp2"] = calculate_rr(entry, sl, tp2)

    return result


# ──────────────────────────────────────────────
# CONFIDENCE SCORE ENGINE
# ──────────────────────────────────────────────

def calculate_score(conditions: dict) -> tuple[int, dict]:
    """
    Score a setup 0–100 using the weighted scoring model.

    conditions keys:
        tf_aligned: bool       — 4H + 1H aligned
        zone_quality: int      — 0–100 zone quality score
        sweep_detected: bool   — liquidity sweep confirmed
        bos_detected: bool     — break of structure confirmed
        retest_held: bool      — retest holds
        in_prime_session: bool — London or NY window
        news_clear: bool       — no high-impact news
        rr_gte_2: bool         — RR >= 2.0
    """
    weights = config.SCORE_WEIGHTS
    breakdown = {}
    total = 0

    # 4H + 1H alignment (20 pts)
    if conditions.get("tf_aligned"):
        breakdown["tf_alignment"] = weights["tf_alignment"]
    else:
        breakdown["tf_alignment"] = 0
    total += breakdown["tf_alignment"]

    # Zone quality (20 pts)
    zq = conditions.get("zone_quality", 0)
    breakdown["zone_quality"] = int(weights["zone_quality"] * (zq / 100))
    total += breakdown["zone_quality"]

    # Liquidity sweep (15 pts)
    if conditions.get("sweep_detected"):
        breakdown["liquidity_sweep"] = weights["liquidity_sweep"]
    else:
        breakdown["liquidity_sweep"] = 0
    total += breakdown["liquidity_sweep"]

    # BOS + Retest (20 pts — split 12/8)
    bos_pts = 12 if conditions.get("bos_detected") else 0
    retest_pts = 8 if conditions.get("retest_held") else 0
    breakdown["bos_retest"] = bos_pts + retest_pts
    total += breakdown["bos_retest"]

    # Session timing (10 pts)
    if conditions.get("in_prime_session"):
        breakdown["session_timing"] = weights["session_timing"]
    else:
        breakdown["session_timing"] = max(0, weights["session_timing"] - config.OFF_SESSION_PENALTY)
    total += breakdown["session_timing"]

    # No news conflict (10 pts)
    if conditions.get("news_clear"):
        breakdown["no_news"] = weights["no_news"]
    else:
        breakdown["no_news"] = 0
    total += breakdown["no_news"]

    # RR bonus (5 pts)
    if conditions.get("rr_gte_2"):
        breakdown["rr_bonus"] = weights["rr_bonus"]
    else:
        breakdown["rr_bonus"] = 0
    total += breakdown["rr_bonus"]

    return min(100, total), breakdown


def get_grade(score: int) -> str:
    if score >= config.GRADE_THRESHOLDS["A"]:
        return "A-grade"
    elif score >= config.GRADE_THRESHOLDS["B"]:
        return "B-grade"
    elif score >= config.GRADE_THRESHOLDS["C"]:
        return "C-grade"
    else:
        return "No trade"


# ──────────────────────────────────────────────
# SETUP EVALUATION — MAIN ENTRY POINT
# ──────────────────────────────────────────────

def evaluate_setups(data: dict[str, pd.DataFrame],
                    all_zones: list[z.Zone],
                    day_levels: dict,
                    session_levels: dict) -> list[Setup]:
    """
    Run the full strategy evaluation across all setup types.
    Returns a list of valid Setup objects (score >= MIN_ALERT_SCORE).
    """
    df_4h = data["4H"]
    df_1h = data["1H"]
    df_15m = data["15M"]
    df_5m = data["5M"]

    current_price = float(df_5m["close"].iloc[-1])
    now = datetime.now(timezone.utc)
    current_session = sess.get_current_session(now)
    in_prime = sess.is_prime_session(now)
    news_status = nf.check_news_status(now)

    # Hard news block
    if news_status["blocked"]:
        return []

    # Determine bias
    bias = st.get_structure_bias(df_4h, df_1h)
    swings_1h = st.get_recent_swings(df_1h)
    swings_15m = st.get_recent_swings(df_15m)

    # Reject neutral bias immediately
    if bias == "neutral":
        return []

    # Reject if price is mid-range
    if st.is_price_in_middle_of_range(df_1h):
        return []

    # Reject if spread/volatility is abnormal
    if not ind.is_spread_acceptable(df_5m):
        return []

    setups = []

    for direction in (["buy"] if bias == "bullish" else ["sell"]):
        opp = "bullish" if direction == "buy" else "bearish"

        # ────────────────────────────────────────
        # SETUP TYPE 1: LIQUIDITY SWEEP REVERSAL
        # ────────────────────────────────────────
        sweep = z.detect_liquidity_sweep(df_15m, swings_15m, opp)
        bos_15m = st.detect_bos(df_15m, opp)
        retest_15m = (
            st.detect_retest(df_15m, bos_15m["bos_level"], opp)
            if bos_15m["bos_detected"] and bos_15m["bos_level"]
            else {"retest_detected": False, "retest_held": False}
        )

        # Find nearest zone
        zone_type = "demand" if direction == "buy" else "supply"
        nearest_zone = z.find_nearest_zone(current_price, all_zones, zone_type)

        zone_quality = nearest_zone.quality_score() if nearest_zone else 0
        tf_aligned = (
            ind.get_trend_direction(df_4h) == opp and
            ind.get_ema_bias(df_1h) == opp
        )

        conditions = {
            "tf_aligned": tf_aligned,
            "zone_quality": zone_quality,
            "sweep_detected": sweep["sweep_detected"],
            "bos_detected": bos_15m["bos_detected"],
            "retest_held": retest_15m.get("retest_held", False),
            "in_prime_session": in_prime,
            "news_clear": not news_status["blocked"],
        }

        # Calculate RR before scoring
        entry = current_price
        levels = calculate_stop_and_tps(
            direction=direction,
            entry=entry,
            sweep_level=sweep.get("sweep_level"),
            zone=nearest_zone,
            swings=swings_1h,
        )

        if levels["stop_pips"] == 0:
            continue  # Invalid stop

        rr = levels["rr_tp2"]
        if rr < config.MIN_RR:
            continue

        conditions["rr_gte_2"] = rr >= config.PREFERRED_RR

        score, breakdown = calculate_score(conditions)
        grade = get_grade(score)

        if score < config.MIN_ALERT_SCORE:
            continue

        # Build reasons list
        reasons = []
        if tf_aligned:
            reasons.append(f"4H and 1H both {opp} — timeframe alignment confirmed")
        if nearest_zone:
            reasons.append(f"Price reacting at {nearest_zone.label} "
                           f"({nearest_zone.bottom:.5f}–{nearest_zone.top:.5f})")
        if sweep["sweep_detected"]:
            reasons.append(f"Liquidity sweep of recent swing detected "
                           f"({sweep['wick_pips']:.1f} pip rejection wick)")
        if bos_15m["bos_detected"]:
            reasons.append(f"15M break of structure above/below {bos_15m['bos_level']:.5f}")
        if retest_15m.get("retest_held"):
            reasons.append("Retest of broken level held — confirmation confirmed")
        if in_prime:
            reasons.append(f"Active {current_session.replace('_', ' ').title()} session")
        if not news_status["blocked"]:
            reasons.append("No major news events in proximity")

        # Invalidation conditions
        invalidations = []
        if direction == "buy":
            invalidations.append(f"Price closes below {levels['stop_loss']:.5f} (stop level)")
            invalidations.append("Bearish BOS on 15M without recovery")
            if nearest_zone:
                invalidations.append(f"Zone {nearest_zone.bottom:.5f} broken to the downside")
        else:
            invalidations.append(f"Price closes above {levels['stop_loss']:.5f} (stop level)")
            invalidations.append("Bullish BOS on 15M without recovery")
            if nearest_zone:
                invalidations.append(f"Zone {nearest_zone.top:.5f} broken to the upside")
        if news_status.get("next_event"):
            invalidations.append(
                f"High-impact news: {news_status['next_event'].title} "
                f"— reassess immediately before/after"
            )

        setup = Setup(
            direction=direction,
            setup_type="liquidity_sweep",
            bias=bias,
            session=current_session,
            entry_low=round(entry - 3 * config.PIP_SIZE, 5),
            entry_high=round(entry + 3 * config.PIP_SIZE, 5),
            stop_loss=levels["stop_loss"],
            tp1=levels["tp1"],
            tp2=levels["tp2"],
            rr=rr,
            score=score,
            score_breakdown=breakdown,
            grade=grade,
            reasons=reasons,
            invalidation_conditions=invalidations,
            news_status=news_status,
            is_valid=True,
        )
        setups.append(setup)

    return setups
