"""
indicators.py — Technical indicator calculations
EMA, trend direction, candle classification, and basic price action helpers.
"""

import pandas as pd
import numpy as np
import config


# ──────────────────────────────────────────────
# MOVING AVERAGES
# ──────────────────────────────────────────────

def add_emas(df: pd.DataFrame) -> pd.DataFrame:
    """Add EMA20 and EMA50 columns to a candle DataFrame."""
    df = df.copy()
    df[f"ema{config.EMA_FAST}"] = df["close"].ewm(span=config.EMA_FAST, adjust=False).mean()
    df[f"ema{config.EMA_SLOW}"] = df["close"].ewm(span=config.EMA_SLOW, adjust=False).mean()
    return df


def get_ema_bias(df: pd.DataFrame) -> str:
    """
    Return 'bullish', 'bearish', or 'neutral' based on EMA relationship
    and price position relative to EMAs.
    """
    df = add_emas(df)
    latest = df.iloc[-1]

    fast_col = f"ema{config.EMA_FAST}"
    slow_col = f"ema{config.EMA_SLOW}"

    price_above_fast = latest["close"] > latest[fast_col]
    price_above_slow = latest["close"] > latest[slow_col]
    fast_above_slow = latest[fast_col] > latest[slow_col]

    if price_above_fast and price_above_slow and fast_above_slow:
        return "bullish"
    elif not price_above_fast and not price_above_slow and not fast_above_slow:
        return "bearish"
    else:
        return "neutral"


# ──────────────────────────────────────────────
# TREND DIRECTION
# ──────────────────────────────────────────────

def get_trend_direction(df: pd.DataFrame, lookback: int = 20) -> str:
    """
    Determine trend direction using higher-highs / higher-lows logic
    over the last `lookback` candles.
    Returns: 'bullish', 'bearish', or 'neutral'
    """
    if len(df) < lookback + 1:
        return "neutral"

    recent = df.tail(lookback)
    highs = recent["high"].values
    lows = recent["low"].values

    # Split into two halves and compare
    mid = lookback // 2
    first_half_high = highs[:mid].max()
    second_half_high = highs[mid:].max()
    first_half_low = lows[:mid].min()
    second_half_low = lows[mid:].min()

    hh = second_half_high > first_half_high
    hl = second_half_low > first_half_low
    lh = second_half_high < first_half_high
    ll = second_half_low < first_half_low

    if hh and hl:
        return "bullish"
    elif lh and ll:
        return "bearish"
    else:
        return "neutral"


# ──────────────────────────────────────────────
# CANDLE CLASSIFICATION
# ──────────────────────────────────────────────

def candle_type(candle: pd.Series) -> str:
    """
    Classify a single candle.
    Returns: 'bullish', 'bearish', 'doji', 'hammer', 'shooting_star'
    """
    body = abs(candle["close"] - candle["open"])
    full_range = candle["high"] - candle["low"]
    upper_wick = candle["high"] - max(candle["open"], candle["close"])
    lower_wick = min(candle["open"], candle["close"]) - candle["low"]

    if full_range == 0:
        return "doji"

    body_ratio = body / full_range

    if body_ratio < 0.1:
        return "doji"

    is_bullish = candle["close"] > candle["open"]

    # Hammer: small body at top, long lower wick
    if lower_wick > body * 2 and upper_wick < body * 0.5:
        return "hammer"

    # Shooting star: small body at bottom, long upper wick
    if upper_wick > body * 2 and lower_wick < body * 0.5:
        return "shooting_star"

    return "bullish" if is_bullish else "bearish"


def is_rejection_candle(candle: pd.Series, direction: str) -> bool:
    """
    Check if a candle shows strong rejection in the given direction.
    direction: 'bullish' (we want bullish rejection) or 'bearish'
    """
    ctype = candle_type(candle)
    if direction == "bullish":
        return ctype in ("bullish", "hammer")
    elif direction == "bearish":
        return ctype in ("bearish", "shooting_star")
    return False


def is_displacement_candle(candle: pd.Series, direction: str,
                           min_pips: float = None) -> bool:
    """
    A displacement candle has a large body relative to its range
    and moves strongly in one direction — sign of institutional order flow.
    """
    if min_pips is None:
        min_pips = config.MIN_BOS_BODY_PIPS

    body = abs(candle["close"] - candle["open"])
    full_range = candle["high"] - candle["low"]
    body_pips = body / config.PIP_SIZE

    if full_range == 0:
        return False

    body_ratio = body / full_range
    is_bullish = candle["close"] > candle["open"]

    if direction == "bullish":
        return is_bullish and body_ratio >= 0.6 and body_pips >= min_pips
    elif direction == "bearish":
        return (not is_bullish) and body_ratio >= 0.6 and body_pips >= min_pips
    return False


# ──────────────────────────────────────────────
# SPREAD / VOLATILITY CHECK
# ──────────────────────────────────────────────

def is_spread_acceptable(df: pd.DataFrame, multiplier: float = 3.0) -> bool:
    """
    Check if recent volatility is within normal range.
    Rejects choppy/abnormal market conditions.
    True = normal, False = avoid.
    """
    if len(df) < 20:
        return True

    recent_ranges = (df["high"] - df["low"]).tail(20)
    avg_range = recent_ranges.mean()
    latest_range = recent_ranges.iloc[-1]

    # Reject if latest candle range is > multiplier × average (spike)
    if latest_range > avg_range * multiplier:
        return False

    # Reject if avg range is abnormally tiny (dead market)
    avg_pips = avg_range / config.PIP_SIZE
    if avg_pips < 2:
        return False

    return True


def get_atr(df: pd.DataFrame, period: int = 14) -> float:
    """Calculate Average True Range (ATR) in pips."""
    if len(df) < period + 1:
        return 0.0

    df = df.copy()
    df["prev_close"] = df["close"].shift(1)
    df["tr"] = df[["high", "prev_close"]].max(axis=1) - df[["low", "prev_close"]].min(axis=1)
    atr = df["tr"].tail(period).mean()
    return atr / config.PIP_SIZE  # Return in pips
