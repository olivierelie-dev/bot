"""
zones.py — Supply/demand zone detection and liquidity sweep logic
Identifies key price zones and detects when price sweeps liquidity.
"""

import pandas as pd
import numpy as np
from typing import Optional
import config
import structure as st


# ──────────────────────────────────────────────
# DATA STRUCTURES
# ──────────────────────────────────────────────

class Zone:
    """Represents a supply or demand zone."""

    def __init__(self, zone_type: str, top: float, bottom: float,
                 strength: int = 1, label: str = ""):
        assert zone_type in ("supply", "demand")
        self.zone_type = zone_type
        self.top = top
        self.bottom = bottom
        self.strength = strength   # Number of times price has respected this zone
        self.label = label         # e.g. "1H supply", "Previous Day High"
        self.midpoint = (top + bottom) / 2
        self.height_pips = (top - bottom) / config.PIP_SIZE

    def contains_price(self, price: float, buffer_pips: float = 2.0) -> bool:
        buffer = buffer_pips * config.PIP_SIZE
        return (self.bottom - buffer) <= price <= (self.top + buffer)

    def is_near_price(self, price: float) -> bool:
        proximity = config.ZONE_PROXIMITY_PIPS * config.PIP_SIZE
        return abs(self.midpoint - price) <= proximity

    def quality_score(self) -> int:
        """Rate zone quality 0–100."""
        score = 50
        # Reward tighter zones (more precise)
        if self.height_pips < 10:
            score += 20
        elif self.height_pips < 20:
            score += 10
        elif self.height_pips > config.MAX_ZONE_HEIGHT_PIPS:
            score -= 20
        # Reward zones that have been respected multiple times
        score += min(self.strength * 10, 30)
        return min(100, max(0, score))

    def __repr__(self):
        return (f"Zone({self.zone_type} | {self.label} | "
                f"{self.bottom:.5f}–{self.top:.5f} | "
                f"strength={self.strength})")


# ──────────────────────────────────────────────
# ZONE DETECTION
# ──────────────────────────────────────────────

def find_supply_demand_zones(df: pd.DataFrame,
                              timeframe_label: str = "1H") -> list[Zone]:
    """
    Identify supply and demand zones from candle data.
    Method: look for strong impulse candles followed by consolidation —
    the origin of the move is the zone.
    """
    zones = []
    if len(df) < 10:
        return zones

    for i in range(5, len(df) - 3):
        candle = df.iloc[i]
        body = abs(candle["close"] - candle["open"])
        full_range = candle["high"] - candle["low"]
        body_pips = body / config.PIP_SIZE

        if full_range == 0 or body_pips < config.MIN_ZONE_HEIGHT_PIPS:
            continue

        body_ratio = body / full_range
        is_bullish = candle["close"] > candle["open"]

        # Only use strong displacement candles as zone origins
        if body_ratio < 0.6:
            continue

        if is_bullish:
            # This bullish impulse came FROM a demand zone
            zone_top = candle["open"]
            zone_bottom = candle["low"]
            height_pips = (zone_top - zone_bottom) / config.PIP_SIZE

            if config.MIN_ZONE_HEIGHT_PIPS <= height_pips <= config.MAX_ZONE_HEIGHT_PIPS:
                zone = Zone(
                    zone_type="demand",
                    top=zone_top,
                    bottom=zone_bottom,
                    label=f"{timeframe_label} demand",
                )
                # Check how many times price has revisited this zone
                zone.strength = _count_zone_touches(df, zone, i)
                zones.append(zone)

        else:
            # This bearish impulse came FROM a supply zone
            zone_top = candle["high"]
            zone_bottom = candle["open"]
            height_pips = (zone_top - zone_bottom) / config.PIP_SIZE

            if config.MIN_ZONE_HEIGHT_PIPS <= height_pips <= config.MAX_ZONE_HEIGHT_PIPS:
                zone = Zone(
                    zone_type="supply",
                    top=zone_top,
                    bottom=zone_bottom,
                    label=f"{timeframe_label} supply",
                )
                zone.strength = _count_zone_touches(df, zone, i)
                zones.append(zone)

    # Remove duplicate/overlapping zones (keep strongest)
    zones = _deduplicate_zones(zones)
    return zones


def _count_zone_touches(df: pd.DataFrame, zone: Zone,
                         origin_idx: int) -> int:
    """Count how many candles after the origin index touched the zone."""
    touches = 0
    future_candles = df.iloc[origin_idx + 1:]
    for _, c in future_candles.iterrows():
        if zone.contains_price(c["low"]) or zone.contains_price(c["high"]):
            touches += 1
    return touches


def _deduplicate_zones(zones: list[Zone]) -> list[Zone]:
    """Remove zones that overlap significantly, keeping the stronger one."""
    if not zones:
        return zones

    filtered = []
    for zone in sorted(zones, key=lambda z: z.strength, reverse=True):
        overlap = False
        for existing in filtered:
            if existing.zone_type != zone.zone_type:
                continue
            # Check for overlap
            if zone.bottom <= existing.top and zone.top >= existing.bottom:
                overlap = True
                break
        if not overlap:
            filtered.append(zone)
    return filtered


# ──────────────────────────────────────────────
# KEY LEVELS (PDH/PDL, session ranges, psych levels)
# ──────────────────────────────────────────────

def build_key_levels(day_levels: dict,
                     session_levels: dict) -> list[Zone]:
    """
    Convert day and session levels into thin Zone objects for scoring.
    """
    key_zones = []

    level_map = {
        "pdh": ("supply", "Previous Day High"),
        "pdl": ("demand", "Previous Day Low"),
        "cdh": ("supply", "Current Day High"),
        "cdl": ("demand", "Current Day Low"),
        "london_high": ("supply", "London High"),
        "london_low": ("demand", "London Low"),
        "ny_high": ("supply", "New York High"),
        "ny_low": ("demand", "New York Low"),
    }

    all_levels = {**day_levels, **session_levels}

    for key, (zone_type, label) in level_map.items():
        price = all_levels.get(key)
        if price is None:
            continue
        thin_zone = 5 * config.PIP_SIZE   # ±5 pips around the level
        zone = Zone(
            zone_type=zone_type,
            top=price + thin_zone,
            bottom=price - thin_zone,
            strength=2,
            label=label,
        )
        key_zones.append(zone)

    # Add psychological levels
    for psych in config.PSYCH_LEVELS:
        thin_zone = config.PSYCH_LEVEL_PROXIMITY_PIPS * config.PIP_SIZE
        zone = Zone(
            zone_type="supply" if psych > 1.08 else "demand",  # rough heuristic
            top=psych + thin_zone,
            bottom=psych - thin_zone,
            strength=1,
            label=f"Psych level {psych:.4f}",
        )
        key_zones.append(zone)

    return key_zones


def find_nearest_zone(price: float, zones: list[Zone],
                       zone_type: Optional[str] = None) -> Optional[Zone]:
    """Return the zone nearest to current price, optionally filtered by type."""
    candidates = [z for z in zones if (zone_type is None or z.zone_type == zone_type)]
    if not candidates:
        return None
    return min(candidates, key=lambda z: abs(z.midpoint - price))


def get_active_zones(price: float, zones: list[Zone]) -> list[Zone]:
    """Return zones that are close to current price."""
    return [z for z in zones if z.is_near_price(price)]


# ──────────────────────────────────────────────
# LIQUIDITY SWEEP DETECTION
# ──────────────────────────────────────────────

def detect_liquidity_sweep(df: pd.DataFrame,
                            swings: dict,
                            direction: str) -> dict:
    """
    Detect if recent price action has swept liquidity (trapped traders).

    direction: 'bullish' = swept a swing low (bears trapped)
               'bearish' = swept a swing high (bulls trapped)

    Returns:
        {
          "sweep_detected": bool,
          "sweep_level": float or None,
          "sweep_candle": pd.Series or None,
          "wick_pips": float,
        }
    """
    result = {
        "sweep_detected": False,
        "sweep_level": None,
        "sweep_candle": None,
        "wick_pips": 0.0,
    }

    recent = df.tail(10)  # Look at last 10 candles for a sweep
    tolerance = config.SWEEP_TOLERANCE_PIPS * config.PIP_SIZE

    if direction == "bullish":
        # We want price to have swept BELOW a recent swing low
        sweep_target = swings.get("latest_swing_low")
        if sweep_target is None:
            return result

        for _, candle in recent.iterrows():
            if candle["low"] < sweep_target - tolerance:
                # Swept below — now check if price closed back above
                if candle["close"] > sweep_target:
                    wick = (candle["close"] - candle["low"]) / config.PIP_SIZE
                    if wick >= config.MIN_SWEEP_WICK_PIPS:
                        result["sweep_detected"] = True
                        result["sweep_level"] = sweep_target
                        result["sweep_candle"] = candle
                        result["wick_pips"] = wick
                        break

    elif direction == "bearish":
        # We want price to have swept ABOVE a recent swing high
        sweep_target = swings.get("latest_swing_high")
        if sweep_target is None:
            return result

        for _, candle in recent.iterrows():
            if candle["high"] > sweep_target + tolerance:
                # Swept above — check if price closed back below
                if candle["close"] < sweep_target:
                    wick = (candle["high"] - candle["close"]) / config.PIP_SIZE
                    if wick >= config.MIN_SWEEP_WICK_PIPS:
                        result["sweep_detected"] = True
                        result["sweep_level"] = sweep_target
                        result["sweep_candle"] = candle
                        result["wick_pips"] = wick
                        break

    return result
