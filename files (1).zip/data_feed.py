"""
data_feed.py — Candle ingestion layer
Supports simulation mode (synthetic data) and live mode via free API.

In simulation mode: generates realistic EUR/USD OHLCV data for testing.
In live mode: fetches from Alpha Vantage (free tier) or a compatible REST feed.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import requests
import os
import logging

import config

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# PUBLIC ENTRY POINT
# ──────────────────────────────────────────────

def get_candles(timeframe_minutes: int, n_candles: int) -> pd.DataFrame:
    """
    Return a DataFrame of OHLCV candles for EUR/USD.
    Columns: open, high, low, close, volume, timestamp
    """
    if config.SIMULATION_MODE:
        return _simulated_candles(timeframe_minutes, n_candles)
    else:
        return _live_candles(timeframe_minutes, n_candles)


def get_all_timeframes() -> dict[str, pd.DataFrame]:
    """
    Fetch candles for all configured timeframes.
    Returns: {"4H": df, "1H": df, "15M": df, "5M": df}
    """
    data = {}
    for label, minutes in config.TIMEFRAMES.items():
        lookback = config.CANDLE_LOOKBACK[label]
        df = get_candles(minutes, lookback)
        data[label] = df
        logger.debug(f"Loaded {len(df)} candles for {label}")
    return data


# ──────────────────────────────────────────────
# SIMULATION MODE
# ──────────────────────────────────────────────

def _simulated_candles(timeframe_minutes: int, n_candles: int) -> pd.DataFrame:
    """
    Generate synthetic but realistic EUR/USD OHLCV candles.
    Uses a random-walk model with drift, volatility, and session effects.
    """
    np.random.seed(42)

    # Realistic starting price
    price = 1.0825
    volatility_per_candle = 0.0008 * (timeframe_minutes / 60) ** 0.5

    records = []
    now = datetime.utcnow()
    # Round down to nearest candle boundary
    start_offset = (now.minute % timeframe_minutes) * 60 + now.second
    base_time = now - timedelta(seconds=start_offset) - timedelta(minutes=timeframe_minutes * n_candles)

    for i in range(n_candles):
        ts = base_time + timedelta(minutes=timeframe_minutes * i)
        hour_utc = ts.hour

        # Session-based volatility multiplier
        if config.LONDON_START_UTC <= hour_utc < config.LONDON_END_UTC:
            vol_mult = 1.4
        elif config.NY_START_UTC <= hour_utc < config.NY_END_UTC:
            vol_mult = 1.3
        elif 0 <= hour_utc < 7:
            vol_mult = 0.5   # Asian dead zone
        else:
            vol_mult = 0.9

        vol = volatility_per_candle * vol_mult

        # Candle construction
        open_price = price
        move = np.random.normal(0, vol)
        close_price = open_price + move

        # High/low with realistic wicks
        upper_wick = abs(np.random.normal(0, vol * 0.4))
        lower_wick = abs(np.random.normal(0, vol * 0.4))
        high_price = max(open_price, close_price) + upper_wick
        low_price = min(open_price, close_price) - lower_wick

        volume = int(np.random.normal(1000, 300) * vol_mult)
        volume = max(100, volume)

        records.append({
            "timestamp": ts,
            "open": round(open_price, 5),
            "high": round(high_price, 5),
            "low": round(low_price, 5),
            "close": round(close_price, 5),
            "volume": volume,
        })

        price = close_price  # Walk forward

    df = pd.DataFrame(records)
    df.set_index("timestamp", inplace=True)
    df.sort_index(inplace=True)
    return df


# ──────────────────────────────────────────────
# LIVE MODE — Alpha Vantage (free tier)
# ──────────────────────────────────────────────

_AV_INTERVAL_MAP = {
    5:   "5min",
    15:  "15min",
    60:  "60min",
    240: "60min",   # 4H: fetch 60min and resample
}

def _live_candles(timeframe_minutes: int, n_candles: int) -> pd.DataFrame:
    """
    Fetch live EUR/USD candles from Alpha Vantage.
    Requires ALPHA_VANTAGE_API_KEY in .env
    """
    api_key = os.getenv("ALPHA_VANTAGE_API_KEY", "")
    if not api_key:
        logger.warning("No ALPHA_VANTAGE_API_KEY found. Falling back to simulation.")
        return _simulated_candles(timeframe_minutes, n_candles)

    interval = _AV_INTERVAL_MAP.get(timeframe_minutes, "60min")
    url = (
        f"https://www.alphavantage.co/query"
        f"?function=FX_INTRADAY"
        f"&from_symbol=EUR&to_symbol=USD"
        f"&interval={interval}"
        f"&outputsize=full"
        f"&apikey={api_key}"
    )

    try:
        resp = requests.get(url, timeout=15)
        resp.raise_for_status()
        raw = resp.json()
        key = f"Time Series FX ({interval})"
        if key not in raw:
            logger.error(f"Unexpected AV response: {list(raw.keys())}")
            return _simulated_candles(timeframe_minutes, n_candles)

        series = raw[key]
        rows = []
        for ts_str, values in series.items():
            rows.append({
                "timestamp": pd.to_datetime(ts_str),
                "open":  float(values["1. open"]),
                "high":  float(values["2. high"]),
                "low":   float(values["3. low"]),
                "close": float(values["4. close"]),
                "volume": 0,  # FX doesn't have real volume on AV free tier
            })

        df = pd.DataFrame(rows)
        df.set_index("timestamp", inplace=True)
        df.sort_index(inplace=True)

        # Resample to 4H if needed
        if timeframe_minutes == 240:
            df = df.resample("4H").agg({
                "open":  "first",
                "high":  "max",
                "low":   "min",
                "close": "last",
                "volume": "sum",
            }).dropna()

        return df.tail(n_candles)

    except Exception as e:
        logger.error(f"Live data fetch failed: {e}. Falling back to simulation.")
        return _simulated_candles(timeframe_minutes, n_candles)


# ──────────────────────────────────────────────
# UTILITIES
# ──────────────────────────────────────────────

def get_current_price(data: dict[str, pd.DataFrame]) -> float:
    """Return the most recent close price from the 5M feed."""
    df = data.get("5M")
    if df is None or df.empty:
        df = data.get("1H")
    if df is not None and not df.empty:
        return float(df["close"].iloc[-1])
    return 0.0


def get_previous_day_levels(data: dict[str, pd.DataFrame]) -> dict:
    """
    Calculate previous day high/low from 1H candles.
    Returns: {"pdh": float, "pdl": float, "cdh": float, "cdl": float}
    """
    df = data.get("1H", pd.DataFrame())
    if df.empty:
        return {}

    df = df.copy()
    df["date"] = df.index.date

    today = df["date"].max()
    yesterday = sorted(df["date"].unique())[-2] if len(df["date"].unique()) >= 2 else today

    prev_day = df[df["date"] == yesterday]
    curr_day = df[df["date"] == today]

    return {
        "pdh": float(prev_day["high"].max()) if not prev_day.empty else None,
        "pdl": float(prev_day["low"].min()) if not prev_day.empty else None,
        "cdh": float(curr_day["high"].max()) if not curr_day.empty else None,
        "cdl": float(curr_day["low"].min()) if not curr_day.empty else None,
    }
