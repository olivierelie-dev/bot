"""
alerts.py — Alert formatting and delivery
Formats setups into the standardized alert format and sends via configured channels.
"""

import requests
import logging
from datetime import datetime, timezone
from scoring import Setup
import config

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# ALERT FORMATTER
# ──────────────────────────────────────────────

def format_alert(setup: Setup) -> str:
    """
    Format a Setup into the standard alert output string.
    This is the exact format specified in the strategy rules.
    """
    direction_str = setup.direction.upper()
    bias_str = setup.bias.capitalize()
    session_str = setup.session.replace("_", " ").title()

    setup_type_map = {
        "liquidity_sweep":   "Liquidity Sweep Reversal",
        "break_retest":      "Break and Retest",
        "session_expansion": "Session Expansion",
    }
    setup_type_str = setup_type_map.get(setup.setup_type, setup.setup_type)

    reasons_str = "\n".join(f"  • {r}" for r in setup.reasons)
    invalidations_str = "\n".join(f"  • {c}" for c in setup.invalidation_conditions)

    # Score bar for visual clarity
    score_bar = _make_score_bar(setup.score)

    alert = f"""
╔══════════════════════════════════════════════╗
  EUR/USD ALERT — {direction_str} SETUP
╚══════════════════════════════════════════════╝

  Bias:        {bias_str}
  Confidence:  {setup.score}/100  {score_bar}
  Session:     {session_str}
  Setup Type:  {setup_type_str}
  Time (UTC):  {setup.timestamp.strftime('%Y-%m-%d %H:%M')}

──────────────────────────────────────────────
  REASON
──────────────────────────────────────────────
{reasons_str}

──────────────────────────────────────────────
  LEVELS
──────────────────────────────────────────────
  Entry Zone:  {setup.entry_low:.5f} – {setup.entry_high:.5f}
  Stop Loss:   {setup.stop_loss:.5f}
  TP1:         {setup.tp1:.5f}
  TP2:         {setup.tp2:.5f}
  RR:          1:{setup.rr}

──────────────────────────────────────────────
  INVALIDATION
──────────────────────────────────────────────
{invalidations_str}

──────────────────────────────────────────────
  TRADE QUALITY:  {setup.grade.upper()}
──────────────────────────────────────────────
"""
    return alert.strip()


def format_no_trade() -> str:
    """Return the standard no-trade message."""
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    return (
        f"[{ts}] NO TRADE — "
        "Conditions do not meet system requirements."
    )


def _make_score_bar(score: int, width: int = 10) -> str:
    """Create a simple ASCII score bar."""
    filled = int((score / 100) * width)
    bar = "█" * filled + "░" * (width - filled)
    return f"[{bar}]"


# ──────────────────────────────────────────────
# DELIVERY CHANNELS
# ──────────────────────────────────────────────

def send_alert(setup: Setup) -> None:
    """Send a formatted alert to all configured channels."""
    message = format_alert(setup)

    for channel in config.ALERT_CHANNELS:
        if channel == "console":
            _send_console(message)
        elif channel == "telegram":
            _send_telegram(message)
        elif channel == "discord":
            _send_discord(message)
        else:
            logger.warning(f"Unknown alert channel: {channel}")


def send_no_trade() -> None:
    """Send or log a no-trade message."""
    msg = format_no_trade()
    if "console" in config.ALERT_CHANNELS:
        print(msg)
    logger.debug(msg)


# ── Console ──────────────────────────────────

def _send_console(message: str) -> None:
    print("\n" + "=" * 50)
    print(message)
    print("=" * 50 + "\n")


# ── Telegram ──────────────────────────────────

def _send_telegram(message: str) -> None:
    token = config.TELEGRAM_BOT_TOKEN
    chat_id = config.TELEGRAM_CHAT_ID

    if not token or not chat_id:
        logger.warning("Telegram not configured — skipping")
        return

    # Telegram has a 4096-char limit
    chunks = [message[i:i+4000] for i in range(0, len(message), 4000)]
    url = f"https://api.telegram.org/bot{token}/sendMessage"

    for chunk in chunks:
        payload = {
            "chat_id": chat_id,
            "text": f"```\n{chunk}\n```",
            "parse_mode": "Markdown",
        }
        try:
            resp = requests.post(url, json=payload, timeout=10)
            resp.raise_for_status()
            logger.info("Telegram alert sent")
        except Exception as e:
            logger.error(f"Telegram send failed: {e}")


# ── Discord ──────────────────────────────────

def _send_discord(message: str) -> None:
    webhook = config.DISCORD_WEBHOOK_URL

    if not webhook:
        logger.warning("Discord webhook not configured — skipping")
        return

    payload = {"content": f"```\n{message}\n```"}
    try:
        resp = requests.post(webhook, json=payload, timeout=10)
        resp.raise_for_status()
        logger.info("Discord alert sent")
    except Exception as e:
        logger.error(f"Discord send failed: {e}")
