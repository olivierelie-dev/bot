"""
news_filter.py — High-impact economic calendar integration
Blocks or downgrades alerts around major news events.
Fetches from ForexFactory RSS or Investing.com API (no key required for basic use).
"""

import requests
import xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta
import logging
import config

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# NEWS EVENT DATA STRUCTURE
# ──────────────────────────────────────────────

class NewsEvent:
    def __init__(self, title: str, currency: str, impact: str,
                 event_time: datetime):
        self.title = title
        self.currency = currency
        self.impact = impact      # 'high', 'medium', 'low'
        self.event_time = event_time

    def is_high_impact(self) -> bool:
        if self.impact == "high":
            return True
        # Keyword-based override
        return any(kw.lower() in self.title.lower()
                   for kw in config.HIGH_IMPACT_EVENTS)

    def minutes_until(self, now: datetime = None) -> float:
        if now is None:
            now = datetime.now(timezone.utc)
        return (self.event_time - now).total_seconds() / 60

    def minutes_since(self, now: datetime = None) -> float:
        return -self.minutes_until(now)

    def __repr__(self):
        return f"NewsEvent({self.title} | {self.currency} | {self.event_time})"


# ──────────────────────────────────────────────
# FETCH NEWS CALENDAR
# ──────────────────────────────────────────────

_news_cache: list[NewsEvent] = []
_cache_fetched_at: datetime = None
_CACHE_TTL_MINUTES = 30


def get_upcoming_events(force_refresh: bool = False) -> list[NewsEvent]:
    """
    Fetch high-impact news events for today.
    Uses a 30-minute cache to avoid excessive API calls.
    Falls back to an empty list if the fetch fails.
    """
    global _news_cache, _cache_fetched_at

    now = datetime.now(timezone.utc)
    cache_stale = (
        _cache_fetched_at is None or
        (now - _cache_fetched_at).total_seconds() > _CACHE_TTL_MINUTES * 60
    )

    if force_refresh or cache_stale:
        fetched = _fetch_forexfactory_rss()
        if fetched is not None:
            _news_cache = fetched
            _cache_fetched_at = now
            logger.info(f"News calendar refreshed: {len(_news_cache)} events")
        else:
            logger.warning("News fetch failed — using cached/empty list")

    return _news_cache


def _fetch_forexfactory_rss() -> list[NewsEvent] | None:
    """
    Attempt to parse ForexFactory's RSS feed.
    NOTE: ForexFactory blocks bots — this is a demonstration.
    Replace with a real calendar API (Investing.com, Myfxbook, etc.)
    for production use.
    """
    try:
        url = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
        headers = {"User-Agent": "Mozilla/5.0"}
        resp = requests.get(url, timeout=10, headers=headers)
        resp.raise_for_status()
        events_raw = resp.json()

        events = []
        for e in events_raw:
            if e.get("impact", "").lower() != "high":
                continue
            currency = e.get("country", "").upper()
            if currency not in config.NEWS_CURRENCIES:
                continue

            # Parse time
            try:
                dt = datetime.fromisoformat(e["date"]).replace(tzinfo=timezone.utc)
            except Exception:
                continue

            event = NewsEvent(
                title=e.get("title", "Unknown"),
                currency=currency,
                impact="high",
                event_time=dt,
            )
            events.append(event)

        return events

    except Exception as exc:
        logger.warning(f"News calendar fetch error: {exc}")
        return None


# ──────────────────────────────────────────────
# NEWS FILTER LOGIC
# ──────────────────────────────────────────────

def check_news_status(now: datetime = None) -> dict:
    """
    Check current news conditions.
    Returns:
        {
          "blocked": bool,          # Hard block — do not alert
          "penalty": int,           # Score penalty (0 or NEWS_NEARBY_PENALTY)
          "reason": str,            # Human-readable reason
          "next_event": NewsEvent or None,
        }
    """
    if now is None:
        now = datetime.now(timezone.utc)

    events = get_upcoming_events()
    relevant = [e for e in events if e.is_high_impact()]

    result = {
        "blocked": False,
        "penalty": 0,
        "reason": "No major news nearby",
        "next_event": None,
    }

    for event in relevant:
        mins_until = event.minutes_until(now)
        mins_since = event.minutes_since(now)

        # Hard block: within the news window
        if -config.NEWS_BLOCK_AFTER_MIN <= mins_until <= config.NEWS_BLOCK_BEFORE_MIN:
            result["blocked"] = True
            if mins_until > 0:
                result["reason"] = (
                    f"⚠️ NEWS BLOCK: {event.title} ({event.currency}) "
                    f"in {mins_until:.0f} min"
                )
            else:
                result["reason"] = (
                    f"⚠️ NEWS BLOCK: {event.title} ({event.currency}) "
                    f"released {mins_since:.0f} min ago"
                )
            result["next_event"] = event
            return result

        # Soft penalty: event within the next 30 minutes
        if 0 < mins_until <= 30:
            result["penalty"] = config.NEWS_NEARBY_PENALTY
            result["reason"] = (
                f"📰 News approaching: {event.title} ({event.currency}) "
                f"in {mins_until:.0f} min"
            )
            result["next_event"] = event

    return result


# ──────────────────────────────────────────────
# SIMULATION HELPERS
# ──────────────────────────────────────────────

def inject_simulated_news_events(events: list[tuple]) -> None:
    """
    Manually inject news events for simulation/testing.
    events: list of (title, currency, datetime_utc)
    """
    global _news_cache, _cache_fetched_at
    _news_cache = [
        NewsEvent(title=t, currency=c, impact="high", event_time=dt)
        for t, c, dt in events
    ]
    _cache_fetched_at = datetime.now(timezone.utc)
