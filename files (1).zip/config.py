"""
config.py — Central configuration for EUR/USD Alert Bot
Tweak thresholds, levels, and settings here without touching strategy logic.
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ──────────────────────────────────────────────
# DATA SETTINGS
# ──────────────────────────────────────────────
SYMBOL = "EURUSD"
SIMULATION_MODE = True          # Set False for live data feed

# Candle timeframes (in minutes)
TIMEFRAMES = {
    "4H": 240,
    "1H": 60,
    "15M": 15,
    "5M": 5,
}

# How many candles to load per timeframe
CANDLE_LOOKBACK = {
    "4H": 100,
    "1H": 200,
    "15M": 300,
    "5M": 500,
}

# ──────────────────────────────────────────────
# INDICATOR SETTINGS
# ──────────────────────────────────────────────
EMA_FAST = 20
EMA_SLOW = 50

# Swing detection: number of candles each side to qualify as a swing
SWING_LOOKBACK = 5

# ──────────────────────────────────────────────
# ZONE SETTINGS
# ──────────────────────────────────────────────
# Pip size for EUR/USD
PIP_SIZE = 0.0001

# How far (in pips) a zone can be from current price to still be "active"
ZONE_PROXIMITY_PIPS = 30

# Minimum zone height in pips
MIN_ZONE_HEIGHT_PIPS = 5

# Max zone height in pips (zones too wide are low-quality)
MAX_ZONE_HEIGHT_PIPS = 40

# ──────────────────────────────────────────────
# LIQUIDITY SWEEP SETTINGS
# ──────────────────────────────────────────────
# How many pips below/above a swing to qualify as a sweep
SWEEP_TOLERANCE_PIPS = 3

# Minimum wick size (in pips) for sweep candle
MIN_SWEEP_WICK_PIPS = 5

# ──────────────────────────────────────────────
# STRUCTURE SETTINGS
# ──────────────────────────────────────────────
# Minimum candle body size (in pips) to count as a BOS candle
MIN_BOS_BODY_PIPS = 4

# ──────────────────────────────────────────────
# RISK / REWARD SETTINGS
# ──────────────────────────────────────────────
MIN_RR = 1.8
PREFERRED_RR = 2.0

# Min/max stop distance in pips
MIN_STOP_PIPS = 8
MAX_STOP_PIPS = 60

# ──────────────────────────────────────────────
# SCORING / CONFIDENCE THRESHOLDS
# ──────────────────────────────────────────────
MIN_ALERT_SCORE = 70

SCORE_WEIGHTS = {
    "tf_alignment": 20,       # 4H + 1H aligned
    "zone_quality": 20,       # Strong supply/demand zone
    "liquidity_sweep": 15,    # Clear sweep/trap
    "bos_retest": 20,         # Break of structure + retest
    "session_timing": 10,     # London / NY window
    "no_news": 10,            # No high-impact news nearby
    "rr_bonus": 5,            # RR >= 2.0
}

GRADE_THRESHOLDS = {
    "A": 85,
    "B": 70,
    "C": 60,   # Below this = no alert
}

# ──────────────────────────────────────────────
# SESSION SETTINGS  (all times in UTC)
# ──────────────────────────────────────────────
# London session: 08:00–11:00 UTC
LONDON_START_UTC = 8
LONDON_END_UTC = 11

# New York session: 13:00–16:00 UTC  (8 AM–11 AM ET = 13–16 UTC)
NY_START_UTC = 13
NY_END_UTC = 16

# Outside-session score penalty (points deducted)
OFF_SESSION_PENALTY = 5

# ──────────────────────────────────────────────
# NEWS FILTER SETTINGS
# ──────────────────────────────────────────────
# Minutes before/after news to block alerts
NEWS_BLOCK_BEFORE_MIN = 15
NEWS_BLOCK_AFTER_MIN = 15

# Score penalty for nearby news (rather than hard block)
NEWS_NEARBY_PENALTY = 10

# High-impact news keywords to watch
HIGH_IMPACT_EVENTS = [
    "CPI", "NFP", "Non-Farm", "FOMC", "Federal Reserve",
    "ECB", "Powell", "Lagarde", "GDP", "Unemployment",
    "Interest Rate Decision", "PMI",
]

# Currencies to filter news for
NEWS_CURRENCIES = ["USD", "EUR"]

# ──────────────────────────────────────────────
# PSYCHOLOGICAL LEVELS
# ──────────────────────────────────────────────
PSYCH_LEVELS = [
    1.0500, 1.0550, 1.0600, 1.0650,
    1.0700, 1.0750, 1.0800, 1.0850,
    1.0900, 1.0950, 1.1000, 1.1050,
    1.1100, 1.1150, 1.1200,
]
PSYCH_LEVEL_PROXIMITY_PIPS = 10

# ──────────────────────────────────────────────
# ALERT DELIVERY
# ──────────────────────────────────────────────
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

DISCORD_WEBHOOK_URL = os.getenv("DISCORD_WEBHOOK_URL", "")

# Which channels to send to (telegram, discord, console)
ALERT_CHANNELS = ["console"]  # Add "telegram" or "discord" when configured

# ──────────────────────────────────────────────
# DATABASE / JOURNAL
# ──────────────────────────────────────────────
DB_PATH = "journal.db"

# ──────────────────────────────────────────────
# SCHEDULER
# ──────────────────────────────────────────────
# How often to run the analysis loop (seconds)
SCAN_INTERVAL_SECONDS = 60
