"""
journal.py — SQLite trade journal
Logs every alert for future review and manual outcome tracking.
"""

import sqlite3
import json
import logging
from datetime import datetime, timezone
from scoring import Setup
import config

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# DB INITIALIZATION
# ──────────────────────────────────────────────

def init_db() -> None:
    """Create journal table if it doesn't exist."""
    with sqlite3.connect(config.DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp     TEXT NOT NULL,
                direction     TEXT,
                setup_type    TEXT,
                bias          TEXT,
                session       TEXT,
                score         INTEGER,
                grade         TEXT,
                entry_low     REAL,
                entry_high    REAL,
                stop_loss     REAL,
                tp1           REAL,
                tp2           REAL,
                rr            REAL,
                reasons       TEXT,    -- JSON array
                invalidations TEXT,    -- JSON array
                score_breakdown TEXT,  -- JSON object
                outcome       TEXT,    -- 'win_tp1', 'win_tp2', 'loss', 'cancelled', NULL
                outcome_pips  REAL,    -- Manually filled later
                notes         TEXT     -- Freeform notes
            )
        """)
        conn.commit()
    logger.info(f"Journal DB initialized at {config.DB_PATH}")


def log_alert(setup: Setup) -> int:
    """
    Insert an alert into the journal.
    Returns the row ID of the inserted record.
    """
    with sqlite3.connect(config.DB_PATH) as conn:
        cursor = conn.execute("""
            INSERT INTO alerts (
                timestamp, direction, setup_type, bias, session,
                score, grade, entry_low, entry_high, stop_loss, tp1, tp2, rr,
                reasons, invalidations, score_breakdown
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            setup.timestamp.isoformat(),
            setup.direction,
            setup.setup_type,
            setup.bias,
            setup.session,
            setup.score,
            setup.grade,
            setup.entry_low,
            setup.entry_high,
            setup.stop_loss,
            setup.tp1,
            setup.tp2,
            setup.rr,
            json.dumps(setup.reasons),
            json.dumps(setup.invalidation_conditions),
            json.dumps(setup.score_breakdown),
        ))
        row_id = cursor.lastrowid
        conn.commit()
    logger.info(f"Alert logged to journal (id={row_id})")
    return row_id


def update_outcome(alert_id: int, outcome: str,
                   outcome_pips: float = 0.0, notes: str = "") -> None:
    """
    Manually update the outcome of a logged alert.
    Call this after you manually review a trade result.

    outcome: 'win_tp1', 'win_tp2', 'loss', 'cancelled'
    """
    with sqlite3.connect(config.DB_PATH) as conn:
        conn.execute("""
            UPDATE alerts
            SET outcome = ?, outcome_pips = ?, notes = ?
            WHERE id = ?
        """, (outcome, outcome_pips, notes, alert_id))
        conn.commit()
    logger.info(f"Alert {alert_id} outcome updated: {outcome} ({outcome_pips} pips)")


def get_recent_alerts(limit: int = 20) -> list[dict]:
    """Fetch the most recent alerts from the journal."""
    with sqlite3.connect(config.DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute("""
            SELECT * FROM alerts
            ORDER BY timestamp DESC
            LIMIT ?
        """, (limit,)).fetchall()
    return [dict(r) for r in rows]


def get_stats() -> dict:
    """Return basic performance statistics from the journal."""
    with sqlite3.connect(config.DB_PATH) as conn:
        total = conn.execute("SELECT COUNT(*) FROM alerts").fetchone()[0]
        with_outcome = conn.execute(
            "SELECT COUNT(*) FROM alerts WHERE outcome IS NOT NULL"
        ).fetchone()[0]
        wins = conn.execute(
            "SELECT COUNT(*) FROM alerts WHERE outcome LIKE 'win%'"
        ).fetchone()[0]
        losses = conn.execute(
            "SELECT COUNT(*) FROM alerts WHERE outcome = 'loss'"
        ).fetchone()[0]
        avg_score = conn.execute(
            "SELECT AVG(score) FROM alerts"
        ).fetchone()[0] or 0
        total_pips = conn.execute(
            "SELECT SUM(outcome_pips) FROM alerts WHERE outcome_pips IS NOT NULL"
        ).fetchone()[0] or 0

    win_rate = (wins / with_outcome * 100) if with_outcome > 0 else 0

    return {
        "total_alerts": total,
        "with_outcome": with_outcome,
        "wins": wins,
        "losses": losses,
        "win_rate_pct": round(win_rate, 1),
        "avg_score": round(avg_score, 1),
        "total_pips": round(total_pips, 1),
    }
