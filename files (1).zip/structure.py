"""
structure.py — Market structure analysis
Swing high/low detection, Break of Structure (BOS), and retest logic.
"""

import pandas as pd
import numpy as np
from typing import Optional
import config
import indicators as ind


# ──────────────────────────────────────────────
# SWING HIGH / LOW DETECTION
# ──────────────────────────────────────────────

def find_swing_highs(df: pd.DataFrame, lookback: int = None) -> pd.Series:
    """
    Return a boolean Series: True where a candle is a swing high.
    A swing high requires `lookback` lower highs on each side.
    """
    if lookback is None:
        lookback = config.SWING_LOOKBACK

    highs = df["high"]
    is_swing = pd.Series(False, index=df.index)

    for i in range(lookback, len(df) - lookback):
        window = highs.iloc[i - lookback: i + lookback + 1]
        if highs.iloc[i] == window.max():
            is_swing.iloc[i] = True

    return is_swing


def find_swing_lows(df: pd.DataFrame, lookback: int = None) -> pd.Series:
    """
    Return a boolean Series: True where a candle is a swing low.
    """
    if lookback is None:
        lookback = config.SWING_LOOKBACK

    lows = df["low"]
    is_swing = pd.Series(False, index=df.index)

    for i in range(lookback, len(df) - lookback):
        window = lows.iloc[i - lookback: i + lookback + 1]
        if lows.iloc[i] == window.min():
            is_swing.iloc[i] = True

    return is_swing


def get_recent_swings(df: pd.DataFrame, n: int = 5) -> dict:
    """
    Return the `n` most recent swing highs and lows as price lists.
    """
    sh_mask = find_swing_highs(df)
    sl_mask = find_swing_lows(df)

    swing_highs = df[sh_mask]["high"].tail(n).tolist()
    swing_lows = df[sl_mask]["low"].tail(n).tolist()

    latest_sh = df[sh_mask]["high"].iloc[-1] if sh_mask.any() else None
    latest_sl = df[sl_mask]["low"].iloc[-1] if sl_mask.any() else None

    return {
        "swing_highs": swing_highs,
        "swing_lows": swing_lows,
        "latest_swing_high": latest_sh,
        "latest_swing_low": latest_sl,
    }


# ──────────────────────────────────────────────
# BREAK OF STRUCTURE (BOS) DETECTION
# ──────────────────────────────────────────────

def detect_bos(df: pd.DataFrame, direction: str) -> dict:
    """
    Detect if a recent Break of Structure has occurred.

    direction: 'bullish' (price breaks above recent swing high)
               'bearish' (price breaks below recent swing low)

    Returns:
        {
          "bos_detected": bool,
          "bos_level": float or None,
          "bos_candle_index": int or None,
        }
    """
    swings = get_recent_swings(df, n=10)
    result = {"bos_detected": False, "bos_level": None, "bos_candle_index": None}

    if direction == "bullish":
        # Look for a close above the most recent significant swing high
        recent_sh = swings.get("latest_swing_high")
        if recent_sh is None:
            return result

        # Check last 5 candles for a bullish BOS
        recent = df.tail(10)
        for i, (_, candle) in enumerate(recent.iterrows()):
            body = abs(candle["close"] - candle["open"]) / config.PIP_SIZE
            if candle["close"] > recent_sh and body >= config.MIN_BOS_BODY_PIPS:
                result["bos_detected"] = True
                result["bos_level"] = recent_sh
                result["bos_candle_index"] = i
                break

    elif direction == "bearish":
        # Look for a close below the most recent significant swing low
        recent_sl = swings.get("latest_swing_low")
        if recent_sl is None:
            return result

        recent = df.tail(10)
        for i, (_, candle) in enumerate(recent.iterrows()):
            body = abs(candle["close"] - candle["open"]) / config.PIP_SIZE
            if candle["close"] < recent_sl and body >= config.MIN_BOS_BODY_PIPS:
                result["bos_detected"] = True
                result["bos_level"] = recent_sl
                result["bos_candle_index"] = i
                break

    return result


# ──────────────────────────────────────────────
# RETEST DETECTION
# ──────────────────────────────────────────────

def detect_retest(df: pd.DataFrame, level: float, direction: str,
                  tolerance_pips: float = 5.0) -> dict:
    """
    After a BOS, check if price has retested the broken level and held.

    direction: 'bullish' = price retested from above (support hold)
               'bearish' = price retested from below (resistance hold)

    Returns:
        {
          "retest_detected": bool,
          "retest_held": bool,   # Did price respect the level and reverse?
          "retest_price": float or None,
        }
    """
    result = {"retest_detected": False, "retest_held": False, "retest_price": None}
    tolerance = tolerance_pips * config.PIP_SIZE
    recent = df.tail(8)  # Check last 8 candles for retest

    for _, candle in recent.iterrows():
        if direction == "bullish":
            # Price dips back toward the broken resistance (now support)
            if (candle["low"] <= level + tolerance and
                    candle["low"] >= level - tolerance):
                result["retest_detected"] = True
                result["retest_price"] = candle["low"]
                # Held: candle closes back above the level
                if candle["close"] > level:
                    result["retest_held"] = True
                break

        elif direction == "bearish":
            # Price rises back toward the broken support (now resistance)
            if (candle["high"] >= level - tolerance and
                    candle["high"] <= level + tolerance):
                result["retest_detected"] = True
                result["retest_price"] = candle["high"]
                # Held: candle closes back below the level
                if candle["close"] < level:
                    result["retest_held"] = True
                break

    return result


# ──────────────────────────────────────────────
# OVERALL STRUCTURE BIAS
# ──────────────────────────────────────────────

def get_structure_bias(df_4h: pd.DataFrame, df_1h: pd.DataFrame) -> str:
    """
    Determine overall market bias using 4H and 1H structure.
    Returns 'bullish', 'bearish', or 'neutral'.
    """
    bias_4h = ind.get_trend_direction(df_4h, lookback=20)
    ema_bias_1h = ind.get_ema_bias(df_1h)
    trend_1h = ind.get_trend_direction(df_1h, lookback=30)

    bullish_votes = sum([
        bias_4h == "bullish",
        ema_bias_1h == "bullish",
        trend_1h == "bullish",
    ])
    bearish_votes = sum([
        bias_4h == "bearish",
        ema_bias_1h == "bearish",
        trend_1h == "bearish",
    ])

    if bullish_votes >= 2:
        return "bullish"
    elif bearish_votes >= 2:
        return "bearish"
    else:
        return "neutral"


def is_price_in_middle_of_range(df: pd.DataFrame, lookback: int = 50) -> bool:
    """
    Returns True if price is stuck in the middle of a range
    (bad entry condition — avoid).
    """
    recent = df.tail(lookback)
    range_high = recent["high"].max()
    range_low = recent["low"].min()
    range_size = range_high - range_low
    if range_size == 0:
        return True

    current_price = df["close"].iloc[-1]
    position = (current_price - range_low) / range_size

    # If price is between 35% and 65% of the range, it's in the middle
    return 0.35 < position < 0.65
