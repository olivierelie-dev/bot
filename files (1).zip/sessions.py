"""
sessions.py — Trading session detection and classification
Tracks London/NY session ranges and current session status.
"""

import pandas as pd
from datetime import datetime, timezone
import config


# ──────────────────────────────────────────────
# SESSION IDENTIFICATION
# ──────────────────────────────────────────────

def get_current_session(dt: datetime = None) -> str:
    """
    Return the current trading session name based on UTC time.
    Returns: 'london', 'new_york', 'overlap', 'asia', 'dead'
    """
    if dt is None:
        dt = datetime.now(timezone.utc)

    hour = dt.hour

    in_london = config.LONDON_START_UTC <= hour < config.LONDON_END_UTC
    in_ny = config.NY_START_UTC <= hour < config.NY_END_UTC

    if in_london and in_ny:
        return "overlap"
    elif in_london:
        return "london"
    elif in_ny:
        return "new_york"
    elif 0 <= hour < 7:
        return "asia"
    else:
        return "dead"


def is_prime_session(dt: datetime = None) -> bool:
    """Returns True if we're in London or NY prime trading window."""
    session = get_current_session(dt)
    return session in ("london", "new_york", "overlap")


def get_session_score_modifier(dt: datetime = None) -> int:
    """
    Returns score adjustment based on session quality.
    Prime sessions: +0 (full points allocated elsewhere)
    Off-session: penalty applied.
    """
    if is_prime_session(dt):
        return 0
    else:
        return -config.OFF_SESSION_PENALTY


# ──────────────────────────────────────────────
# SESSION RANGE TRACKING
# ──────────────────────────────────────────────

def get_session_ranges(df: pd.DataFrame) -> dict:
    """
    Calculate London and New York session high/low from 1H candle data.
    Returns: {"london_high": float, "london_low": float,
              "ny_high": float, "ny_low": float}
    """
    result = {
        "london_high": None,
        "london_low": None,
        "ny_high": None,
        "ny_low": None,
    }

    if df.empty:
        return result

    df = df.copy()
    today = datetime.now(timezone.utc).date()

    # Filter to today only
    df_today = df[df.index.date == today] if hasattr(df.index, "date") else df

    if df_today.empty:
        return result

    # London session candles
    london_mask = (
        (df_today.index.hour >= config.LONDON_START_UTC) &
        (df_today.index.hour < config.LONDON_END_UTC)
    )
    london = df_today[london_mask]
    if not london.empty:
        result["london_high"] = float(london["high"].max())
        result["london_low"] = float(london["low"].min())

    # New York session candles
    ny_mask = (
        (df_today.index.hour >= config.NY_START_UTC) &
        (df_today.index.hour < config.NY_END_UTC)
    )
    ny = df_today[ny_mask]
    if not ny.empty:
        result["ny_high"] = float(ny["high"].max())
        result["ny_low"] = float(ny["low"].min())

    return result


# ──────────────────────────────────────────────
# SESSION EXPANSION DETECTION
# ──────────────────────────────────────────────

def detect_session_expansion(df_5m: pd.DataFrame,
                              session: str,
                              direction: str) -> dict:
    """
    Detect if a session opened with a strong directional expansion.

    session: 'london' or 'new_york'
    direction: 'bullish' or 'bearish'

    Returns:
        {
          "expansion_detected": bool,
          "displacement_pips": float,
          "pullback_occurred": bool,
        }
    """
    result = {
        "expansion_detected": False,
        "displacement_pips": 0.0,
        "pullback_occurred": False,
    }

    if df_5m.empty or len(df_5m) < 10:
        return result

    # Determine session open hour
    open_hour = config.LONDON_START_UTC if session == "london" else config.NY_START_UTC

    # Find the first candles of the session
    today = datetime.now(timezone.utc).date()
    session_mask = (
        (df_5m.index.date == today) &
        (df_5m.index.hour == open_hour)
    )
    session_open = df_5m[session_mask]

    if session_open.empty:
        return result

    # First 3 candles of the session
    first_candles = session_open.head(3)

    # Calculate total displacement
    open_price = float(first_candles["open"].iloc[0])
    close_price = float(first_candles["close"].iloc[-1])
    displacement = (close_price - open_price) / config.PIP_SIZE

    min_displacement_pips = 10  # Must move at least 10 pips to qualify

    if direction == "bullish" and displacement >= min_displacement_pips:
        result["expansion_detected"] = True
        result["displacement_pips"] = displacement

        # Check for pullback after expansion
        post_open = df_5m[df_5m.index > session_open.index[-1]].head(6)
        if not post_open.empty:
            pullback = (post_open["close"].max() - post_open["close"].min()) / config.PIP_SIZE
            result["pullback_occurred"] = pullback >= 3

    elif direction == "bearish" and displacement <= -min_displacement_pips:
        result["expansion_detected"] = True
        result["displacement_pips"] = abs(displacement)

        post_open = df_5m[df_5m.index > session_open.index[-1]].head(6)
        if not post_open.empty:
            pullback = (post_open["close"].max() - post_open["close"].min()) / config.PIP_SIZE
            result["pullback_occurred"] = pullback >= 3

    return result
