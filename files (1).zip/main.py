"""
main.py — Entry point for the EUR/USD Alert Bot
Runs the analysis loop on a configurable schedule.

IMPORTANT: This bot NEVER places trades. It only analyzes and alerts.
"""

import time
import logging
import argparse
from datetime import datetime, timezone

import config
import logger as log_setup
import data_feed
import zones as z
import sessions as sess
import scoring
import alerts
import journal


def run_once(verbose: bool = False) -> None:
    """
    Execute one full analysis cycle.
    - Fetch candles
    - Detect zones
    - Evaluate setups
    - Send alerts
    - Log to journal
    """
    logger = logging.getLogger("main")
    now = datetime.now(timezone.utc)
    logger.info(f"Running analysis cycle — {now.strftime('%Y-%m-%d %H:%M UTC')}")

    # ── 1. Fetch all timeframe data ──
    try:
        data = data_feed.get_all_timeframes()
    except Exception as e:
        logger.error(f"Data fetch failed: {e}")
        return

    # ── 2. Extract key levels ──
    day_levels = data_feed.get_previous_day_levels(data)
    session_levels = sess.get_session_ranges(data["1H"])
    current_price = data_feed.get_current_price(data)

    if verbose:
        logger.info(f"Current price: {current_price:.5f}")
        logger.info(f"Day levels: {day_levels}")
        logger.info(f"Session levels: {session_levels}")

    # ── 3. Identify supply/demand zones ──
    zones_1h = z.find_supply_demand_zones(data["1H"], timeframe_label="1H")
    key_level_zones = z.build_key_levels(day_levels, session_levels)
    all_zones = zones_1h + key_level_zones

    if verbose:
        logger.info(f"Zones detected: {len(all_zones)} "
                    f"({len(zones_1h)} supply/demand, {len(key_level_zones)} key levels)")

    # ── 4. Evaluate setups ──
    setups = scoring.evaluate_setups(data, all_zones, day_levels, session_levels)

    # ── 5. Send alerts ──
    if setups:
        for setup in setups:
            logger.info(
                f"SETUP FOUND: {setup.direction.upper()} | "
                f"Score {setup.score}/100 | {setup.grade}"
            )
            alerts.send_alert(setup)
            journal.log_alert(setup)
    else:
        alerts.send_no_trade()
        logger.debug("No valid setups this cycle")


def run_loop() -> None:
    """
    Continuous analysis loop with configurable interval.
    Runs indefinitely until interrupted.
    """
    logger = logging.getLogger("main")
    logger.info(
        f"Starting EUR/USD Alert Bot — "
        f"{'SIMULATION' if config.SIMULATION_MODE else 'LIVE'} mode"
    )
    logger.info(f"Scan interval: {config.SCAN_INTERVAL_SECONDS}s")
    logger.info("⚠️  This bot NEVER places trades — alerts only.")

    journal.init_db()

    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            logger.info("Bot stopped by user.")
            break
        except Exception as e:
            logger.error(f"Unexpected error in main loop: {e}", exc_info=True)

        logger.debug(f"Sleeping {config.SCAN_INTERVAL_SECONDS}s...")
        time.sleep(config.SCAN_INTERVAL_SECONDS)


def show_stats() -> None:
    """Print journal performance statistics."""
    journal.init_db()
    stats = journal.get_stats()
    print("\n── Journal Statistics ──────────────")
    for k, v in stats.items():
        print(f"  {k:<20}: {v}")
    print("─────────────────────────────────────\n")


# ──────────────────────────────────────────────
# CLI ENTRY POINT
# ──────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="EUR/USD Trading Alert Bot — analysis only, no auto-execution"
    )
    parser.add_argument(
        "--mode",
        choices=["run", "once", "stats"],
        default="run",
        help=(
            "run = continuous loop | "
            "once = single analysis cycle | "
            "stats = show journal stats"
        ),
    )
    parser.add_argument("--verbose", action="store_true", help="Extra logging")
    parser.add_argument("--log-level", default="INFO", help="Logging level")
    args = parser.parse_args()

    log_setup.setup_logging(level=args.log_level)

    if args.mode == "run":
        run_loop()
    elif args.mode == "once":
        journal.init_db()
        run_once(verbose=args.verbose)
    elif args.mode == "stats":
        show_stats()
