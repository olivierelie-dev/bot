"""
structure.py — Per-stock trend and level analysis
Detects trend direction, key support/resistance, and swing points.
"""

import pandas as pd
import numpy as np
from typing import Optional
import config


# ──────────────────────────────────────────────
# EMA
# ──────────────────────────────────────────────

def add_emas(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["ema20"] = df["close"].ewm(span=20, adjust=False).mean()
    df["ema50"] = df["close"].ewm(span=50, adjust=False).mean()
    return df


# ──────────────────────────────────────────────
# TREND
# ──────────────────────────────────────────────

def get_trend(df: pd.DataFrame, lookback: int = 20) -> str:
    """
    Returns 'bullish', 'bearish', or 'neutral' for the stock's trend.
    Uses EMA position + higher-highs/lows structure.
    """
    if len(df) < lookback + 1:
        return "neutral"

    df = add_emas(df)
    last = df.iloc[-1]

    price_above_ema20 = last["close"] > last["ema20"]
    price_above_ema50 = last["close"] > last["ema50"]
    ema20_above_ema50 = last["ema20"] > last["ema50"]

    recent = df.tail(lookback)
    highs  = recent["high"].values
    lows   = recent["low"].values
    mid    = lookback // 2

    hh = highs[mid:].max() > highs[:mid].max()
    hl = lows[mid:].min()  > lows[:mid].min()
    lh = highs[mid:].max() < highs[:mid].max()
    ll = lows[mid:].min()  < lows[:mid].min()

    bull_votes = sum([price_above_ema20, price_above_ema50, ema20_above_ema50, hh, hl])
    bear_votes = sum([not price_above_ema20, not price_above_ema50,
                      not ema20_above_ema50, lh, ll])

    if bull_votes >= 3:
        return "bullish"
    elif bear_votes >= 3:
        return "bearish"
    return "neutral"


# ──────────────────────────────────────────────
# SWING HIGHS / LOWS
# ──────────────────────────────────────────────

def find_swing_highs(df: pd.DataFrame, n: int = None) -> pd.Series:
    n = n or config.SWING_LOOKBACK
    highs = df["high"]
    result = pd.Series(False, index=df.index)
    for i in range(n, len(df) - n):
        window = highs.iloc[i - n: i + n + 1]
        if highs.iloc[i] == window.max():
            result.iloc[i] = True
    return result


def find_swing_lows(df: pd.DataFrame, n: int = None) -> pd.Series:
    n = n or config.SWING_LOOKBACK
    lows = df["low"]
    result = pd.Series(False, index=df.index)
    for i in range(n, len(df) - n):
        window = lows.iloc[i - n: i + n + 1]
        if lows.iloc[i] == window.min():
            result.iloc[i] = True
    return result


def get_key_levels(df: pd.DataFrame, n_levels: int = 5) -> dict:
    """
    Return the most recent swing highs and lows as resistance/support levels.
    """
    sh_mask = find_swing_highs(df)
    sl_mask = find_swing_lows(df)

    resistance_levels = sorted(df[sh_mask]["high"].tail(n_levels).tolist(), reverse=True)
    support_levels    = sorted(df[sl_mask]["low"].tail(n_levels).tolist(), reverse=True)

    current_price = float(df["close"].iloc[-1])

    # Nearest resistance above current price
    above = [l for l in resistance_levels if l > current_price]
    nearest_resistance = min(above) if above else None

    # Nearest support below current price
    below = [l for l in support_levels if l < current_price]
    nearest_support = max(below) if below else None

    return {
        "resistance_levels": resistance_levels,
        "support_levels": support_levels,
        "nearest_resistance": nearest_resistance,
        "nearest_support": nearest_support,
    }


# ──────────────────────────────────────────────
# VOLUME
# ──────────────────────────────────────────────

def detect_volume_spike(df: pd.DataFrame,
                         lookback: int = 20) -> dict:
    """
    Detect if recent volume is significantly above average.
    Returns: {"spike": bool, "ratio": float, "avg_volume": float}
    """
    if len(df) < lookback + 1:
        return {"spike": False, "ratio": 1.0, "avg_volume": 0}

    avg_vol    = float(df["volume"].iloc[-(lookback + 1):-1].mean())
    latest_vol = float(df["volume"].iloc[-1])
    ratio      = latest_vol / max(avg_vol, 1)

    return {
        "spike": ratio >= config.VOLUME_SPIKE_MULTIPLIER,
        "ratio": round(ratio, 2),
        "avg_volume": avg_vol,
        "latest_volume": latest_vol,
    }


# ──────────────────────────────────────────────
# CANDLE CLASSIFICATION
# ──────────────────────────────────────────────

def classify_candle(candle: pd.Series) -> str:
    """Returns 'bullish', 'bearish', 'doji', 'hammer', or 'shooting_star'."""
    body = abs(candle["close"] - candle["open"])
    full = candle["high"] - candle["low"]
    if full == 0:
        return "doji"
    body_ratio = body / full
    is_bull = candle["close"] > candle["open"]
    upper = candle["high"] - max(candle["open"], candle["close"])
    lower = min(candle["open"], candle["close"]) - candle["low"]

    if body_ratio < 0.1:
        return "doji"
    if lower > body * 2 and upper < body * 0.5:
        return "hammer"
    if upper > body * 2 and lower < body * 0.5:
        return "shooting_star"
    return "bullish" if is_bull else "bearish"


def get_confirmation_candle(df: pd.DataFrame, direction: str) -> bool:
    """Check if the most recent closed candle confirms the setup direction."""
    if len(df) < 2:
        return False
    last = df.iloc[-1]
    ctype = classify_candle(last)
    if direction == "call":
        return ctype in ("bullish", "hammer")
    elif direction == "put":
        return ctype in ("bearish", "shooting_star")
    return False


# ──────────────────────────────────────────────
# EXTENDED / OVEREXTENDED CHECK
# ──────────────────────────────────────────────

def is_entry_extended(df: pd.DataFrame, direction: str,
                       atr_multiple: float = 2.5) -> bool:
    """
    Returns True if price is too far from EMA — entry is late / overextended.
    Prevents chasing.
    """
    if len(df) < 20:
        return False

    df = add_emas(df)
    last = df.iloc[-1]
    price = last["close"]
    ema   = last["ema20"]

    # ATR-based distance check
    tr = (df["high"] - df["low"]).tail(14).mean()
    distance = abs(price - ema)

    return distance > atr_multiple * tr
