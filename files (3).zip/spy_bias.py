"""
spy_bias.py — SPY market direction engine
All stock trades must align with SPY bias.
Uses 5M and 15M candles to determine bullish / bearish / neutral.
"""

import pandas as pd
import numpy as np
import logging
from datetime import datetime, timezone

import config
import data_feed

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# EMA HELPERS
# ──────────────────────────────────────────────

def add_ema(df: pd.DataFrame, period: int) -> pd.DataFrame:
    df = df.copy()
    df[f"ema{period}"] = df["close"].ewm(span=period, adjust=False).mean()
    return df


def get_ema_position(df: pd.DataFrame) -> str:
    """
    Returns 'above' if price is above both EMAs (bullish structure),
    'below' if under both, 'mixed' if between them.
    """
    df = add_ema(df, config.SPY_EMA_FAST)
    df = add_ema(df, config.SPY_EMA_SLOW)
    last = df.iloc[-1]

    above_fast = last["close"] > last[f"ema{config.SPY_EMA_FAST}"]
    above_slow = last["close"] > last[f"ema{config.SPY_EMA_SLOW}"]

    if above_fast and above_slow:
        return "above"
    elif not above_fast and not above_slow:
        return "below"
    else:
        return "mixed"


# ──────────────────────────────────────────────
# TREND STRUCTURE
# ──────────────────────────────────────────────

def get_hh_hl_or_ll_lh(df: pd.DataFrame, n: int = 20) -> str:
    """
    Classify price structure over last n candles.
    Returns 'bullish' (HH+HL), 'bearish' (LH+LL), or 'neutral'.
    """
    recent = df.tail(n)
    if len(recent) < 4:
        return "neutral"

    highs = recent["high"].values
    lows  = recent["low"].values
    mid   = len(highs) // 2

    hh = highs[mid:].max() > highs[:mid].max()
    hl = lows[mid:].min()  > lows[:mid].min()
    lh = highs[mid:].max() < highs[:mid].max()
    ll = lows[mid:].min()  < lows[:mid].min()

    if hh and hl:
        return "bullish"
    elif lh and ll:
        return "bearish"
    return "neutral"


# ──────────────────────────────────────────────
# OPENING MOMENTUM
# ──────────────────────────────────────────────

def get_opening_momentum(df_5m: pd.DataFrame) -> str:
    """
    Evaluate the first 30 minutes of the session (first 6 × 5M candles).
    Returns 'strong_bullish', 'strong_bearish', or 'neutral'.
    """
    today = datetime.now(timezone.utc).date()
    today_candles = df_5m[df_5m.index.date == today] if hasattr(df_5m.index, "date") else df_5m
    open_candles = today_candles.head(6)   # First 30 min

    if len(open_candles) < 3:
        return "neutral"

    open_price = float(open_candles["open"].iloc[0])
    last_close = float(open_candles["close"].iloc[-1])
    move_pct = (last_close - open_price) / open_price * 100

    # Strong if > 0.5% move in first 30 min
    if move_pct >= 0.5:
        return "strong_bullish"
    elif move_pct <= -0.5:
        return "strong_bearish"
    return "neutral"


# ──────────────────────────────────────────────
# MAIN BIAS FUNCTION
# ──────────────────────────────────────────────

def get_spy_bias() -> dict:
    """
    Determine overall SPY market bias.

    Returns:
        {
          "bias": "bullish" | "bearish" | "neutral",
          "strength": 0–100,
          "ema_position_5m": str,
          "structure_15m": str,
          "opening_momentum": str,
          "details": str,
        }
    """
    try:
        df_5m  = data_feed.get_candles("SPY", interval="5m",  period="5d")
        df_15m = data_feed.get_candles("SPY", interval="15m", period="5d")
    except Exception as e:
        logger.error(f"SPY data fetch failed: {e}")
        return _neutral_bias("Data fetch error")

    ema_pos   = get_ema_position(df_5m)
    structure = get_hh_hl_or_ll_lh(df_15m, n=config.SPY_LOOKBACK_CANDLES)
    momentum  = get_opening_momentum(df_5m)

    # Vote-based decision
    bull_votes = sum([
        ema_pos == "above",
        structure == "bullish",
        momentum == "strong_bullish",
    ])
    bear_votes = sum([
        ema_pos == "below",
        structure == "bearish",
        momentum == "strong_bearish",
    ])

    if bull_votes >= 2:
        bias = "bullish"
        strength = int(30 + bull_votes * 23)
    elif bear_votes >= 2:
        bias = "bearish"
        strength = int(30 + bear_votes * 23)
    else:
        bias = "neutral"
        strength = 30

    details = (
        f"5M EMA: {ema_pos} | "
        f"15M structure: {structure} | "
        f"Opening momentum: {momentum}"
    )
    logger.info(f"SPY bias: {bias} ({strength}) — {details}")

    return {
        "bias": bias,
        "strength": min(100, strength),
        "ema_position_5m": ema_pos,
        "structure_15m": structure,
        "opening_momentum": momentum,
        "details": details,
        "spy_5m": df_5m,
        "spy_15m": df_15m,
    }


def _neutral_bias(reason: str) -> dict:
    return {
        "bias": "neutral",
        "strength": 0,
        "ema_position_5m": "unknown",
        "structure_15m": "unknown",
        "opening_momentum": "unknown",
        "details": reason,
        "spy_5m": pd.DataFrame(),
        "spy_15m": pd.DataFrame(),
    }
