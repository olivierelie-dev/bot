# Changelog

All notable changes follow [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.0.0] — 2026-03-22

### Added
- Initial Version 1 release
- SPY bias engine: 5M EMA + 15M structure + opening momentum voting
- Market scanner: top gainers, losers, and volume spikes from watchlist
- Three setup detectors: Breakout, Pullback Continuation, Reversal
- Options contract selector: delta 0.30–0.60, DTE filters, liquidity/spread checks
- 100-point confidence scoring: SPY alignment, trend, volume, setup, options, news, timing
- A+ (85+) and B (70+) grade thresholds
- Structured alert format: ticker, bias, score, setup, contract, levels, trade plan, invalidations
- Option targets: TP1 +50%, TP2 +100%
- Option stop: −35% from entry mid
- Structure-based stock stop levels (support/resistance)
- Simulation mode with synthetic OHLCV and option chain data
- Live mode via yfinance (free, no key required)
- Telegram and Discord webhook delivery
- SQLite journal with outcome tracking
- CLI: `--mode run`, `--mode once`, `--mode stats`
- `.env.example`, `.gitignore`, `requirements.txt`

### Security
- No broker credentials or auto-execution code
- All secrets via `.env`, excluded from version control
