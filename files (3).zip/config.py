"""
config.py — Central configuration for Stock + Options Alert Bot
All thresholds, tickers, and settings live here. Tweak freely.
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ──────────────────────────────────────────────
# MODE
# ──────────────────────────────────────────────
SIMULATION_MODE = True       # True = use synthetic/cached data, no live API calls

# ──────────────────────────────────────────────
# UNIVERSE
# ──────────────────────────────────────────────
# Core watchlist — high liquidity, options-friendly
WATCHLIST = [
    "SPY", "QQQ",
    "AAPL", "TSLA", "NVDA", "META", "AMD", "AMZN",
    "MSFT", "GOOG", "NFLX", "MU", "MSTR", "PLTR",
]

# Minimum average daily volume to consider a stock
MIN_AVG_VOLUME = 5_000_000

# Minimum price — avoid penny stocks
MIN_STOCK_PRICE = 10.0

# ──────────────────────────────────────────────
# SPY BIAS
# ──────────────────────────────────────────────
SPY_EMA_FAST = 20
SPY_EMA_SLOW = 50
SPY_LOOKBACK_CANDLES = 30    # Candles used for trend direction on 5M/15M

# ──────────────────────────────────────────────
# SCANNER THRESHOLDS
# ──────────────────────────────────────────────
# Minimum % move to qualify as a top gainer/loser
MIN_MOVE_PCT = 1.5

# Volume spike: current volume vs average
VOLUME_SPIKE_MULTIPLIER = 1.5   # 1.5× = 50% above average

# How many top movers to scan
TOP_MOVERS_COUNT = 10

# ──────────────────────────────────────────────
# STRUCTURE / SETUP
# ──────────────────────────────────────────────
# Swing lookback (candles each side)
SWING_LOOKBACK = 5

# Breakout: how close to resistance to count as "at" the level (%)
BREAKOUT_PROXIMITY_PCT = 0.5

# Pullback: how far from EMA before calling it a "pullback" (%)
PULLBACK_EMA_BUFFER_PCT = 1.0

# Minimum candles in consolidation before a breakout
MIN_CONSOLIDATION_CANDLES = 3

# ──────────────────────────────────────────────
# OPTIONS SELECTION
# ──────────────────────────────────────────────
# Delta range for contract selection
OPTION_DELTA_MIN = 0.30
OPTION_DELTA_MAX = 0.60

# DTE ranges
MOMENTUM_DTE_MAX = 5         # 0–5 DTE for momentum trades
SWING_DTE_MIN = 7
SWING_DTE_MAX = 21           # 1–3 weeks for swing trades

# Liquidity filters
MIN_OPTION_VOLUME = 100
MIN_OPEN_INTEREST = 500
MAX_BID_ASK_SPREAD_PCT = 10.0   # Max spread as % of mid price

# ──────────────────────────────────────────────
# RISK / REWARD
# ──────────────────────────────────────────────
# Option price stop: cut if option loses this % of value
OPTION_STOP_LOSS_PCT = 35.0

# Take profit levels
TP1_PCT = 50.0
TP2_PCT = 100.0

# ──────────────────────────────────────────────
# SCORING
# ──────────────────────────────────────────────
MIN_ALERT_SCORE = 70

SCORE_WEIGHTS = {
    "spy_alignment":   20,
    "trend_quality":   15,
    "volume_confirm":  15,
    "setup_quality":   20,
    "options_quality": 10,
    "news_catalyst":   10,
    "entry_timing":    10,
}

GRADE_THRESHOLDS = {
    "A+": 85,
    "B":  70,
}

# ──────────────────────────────────────────────
# SESSION / TIMING  (all times Eastern)
# ──────────────────────────────────────────────
MARKET_OPEN_HOUR_ET = 9
MARKET_OPEN_MIN_ET = 30
MARKET_CLOSE_HOUR_ET = 16

# Prime trading windows (ET)
PRIME_OPEN_END_HOUR = 11      # 9:30–11:00 AM power hour
PRIME_CLOSE_START_HOUR = 14   # 2:00–4:00 PM close drive

# Avoid trading within this many minutes of close
AVOID_CLOSE_MINUTES = 15

# ──────────────────────────────────────────────
# ALERT DELIVERY
# ──────────────────────────────────────────────
TELEGRAM_BOT_TOKEN  = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID    = os.getenv("TELEGRAM_CHAT_ID", "")
DISCORD_WEBHOOK_URL = os.getenv("DISCORD_WEBHOOK_URL", "")

ALERT_CHANNELS = ["console"]   # Add "telegram" or "discord" when configured

# ──────────────────────────────────────────────
# DATABASE
# ──────────────────────────────────────────────
DB_PATH = "journal.db"

# ──────────────────────────────────────────────
# SCHEDULER
# ──────────────────────────────────────────────
SCAN_INTERVAL_SECONDS = 60

# ──────────────────────────────────────────────
# DATA PROVIDERS  (set keys in .env)
# ──────────────────────────────────────────────
POLYGON_API_KEY  = os.getenv("POLYGON_API_KEY", "")
ALPACA_API_KEY   = os.getenv("ALPACA_API_KEY", "")
ALPACA_API_SECRET = os.getenv("ALPACA_API_SECRET", "")
# yfinance requires no key — used as free fallback
