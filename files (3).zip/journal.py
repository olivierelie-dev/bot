"""
journal.py — SQLite trade journal
Logs every alert. Manual outcome tracking after you review each trade.
"""

import sqlite3
import json
import logging
from datetime import datetime, timezone
from scoring import Setup
import config

logger = logging.getLogger(__name__)


def init_db() -> None:
    with sqlite3.connect(config.DB_PATH) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp        TEXT NOT NULL,
                ticker           TEXT,
                direction        TEXT,
                setup_type       TEXT,
                market_bias      TEXT,
                score            INTEGER,
                grade            TEXT,
                option_strike    REAL,
                option_expiry    TEXT,
                option_dte       INTEGER,
                option_delta     REAL,
                option_mid       REAL,
                stock_stop       REAL,
                stock_tp1        REAL,
                stock_tp2        REAL,
                option_tp1       REAL,
                option_tp2       REAL,
                reasons          TEXT,
                invalidations    TEXT,
                score_breakdown  TEXT,
                outcome          TEXT,
                outcome_pct      REAL,
                notes            TEXT
            )
        """)
        conn.commit()


def log_alert(setup: Setup) -> int:
    c = setup.contract
    t = setup.option_targets
    with sqlite3.connect(config.DB_PATH) as conn:
        cursor = conn.execute("""
            INSERT INTO alerts (
                timestamp, ticker, direction, setup_type, market_bias,
                score, grade,
                option_strike, option_expiry, option_dte, option_delta, option_mid,
                stock_stop, stock_tp1, stock_tp2, option_tp1, option_tp2,
                reasons, invalidations, score_breakdown
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            setup.timestamp.isoformat(),
            setup.ticker, setup.direction, setup.setup_type, setup.market_bias,
            setup.score, setup.grade,
            c.strike if c else None,
            c.expiry if c else None,
            c.dte    if c else None,
            c.delta  if c else None,
            c.mid    if c else None,
            setup.stock_stop, setup.stock_target1, setup.stock_target2,
            t.get("tp1_price"), t.get("tp2_price"),
            json.dumps(setup.reasons),
            json.dumps(setup.invalidations),
            json.dumps(setup.score_breakdown),
        ))
        row_id = cursor.lastrowid
        conn.commit()
    logger.info(f"Alert logged (id={row_id}): {setup.ticker} {setup.direction.upper()}")
    return row_id


def update_outcome(alert_id: int, outcome: str,
                   outcome_pct: float = 0.0, notes: str = "") -> None:
    """
    outcome: 'win_tp1', 'win_tp2', 'loss', 'cancelled'
    outcome_pct: actual % gain/loss on the option
    """
    with sqlite3.connect(config.DB_PATH) as conn:
        conn.execute("""
            UPDATE alerts SET outcome=?, outcome_pct=?, notes=? WHERE id=?
        """, (outcome, outcome_pct, notes, alert_id))
        conn.commit()


def get_stats() -> dict:
    with sqlite3.connect(config.DB_PATH) as conn:
        total       = conn.execute("SELECT COUNT(*) FROM alerts").fetchone()[0]
        with_out    = conn.execute("SELECT COUNT(*) FROM alerts WHERE outcome IS NOT NULL").fetchone()[0]
        wins        = conn.execute("SELECT COUNT(*) FROM alerts WHERE outcome LIKE 'win%'").fetchone()[0]
        losses      = conn.execute("SELECT COUNT(*) FROM alerts WHERE outcome='loss'").fetchone()[0]
        avg_score   = conn.execute("SELECT AVG(score) FROM alerts").fetchone()[0] or 0
        avg_outcome = conn.execute("SELECT AVG(outcome_pct) FROM alerts WHERE outcome_pct IS NOT NULL").fetchone()[0] or 0

    return {
        "total_alerts": total,
        "with_outcome": with_out,
        "wins": wins,
        "losses": losses,
        "win_rate_pct": round(wins / with_out * 100, 1) if with_out else 0,
        "avg_score": round(avg_score, 1),
        "avg_option_pct": round(avg_outcome, 1),
    }
