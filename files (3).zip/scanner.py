"""
scanner.py — Market scanner
Identifies actionable candidates from the watchlist.
Filters by liquidity, momentum, and basic structure quality.
"""

import pandas as pd
import logging
from dataclasses import dataclass, field

import config
import data_feed
import structure as st

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# CANDIDATE DATA STRUCTURE
# ──────────────────────────────────────────────

@dataclass
class Candidate:
    ticker: str
    price: float
    change_pct: float
    volume_ratio: float
    trend: str             # 'bullish', 'bearish', 'neutral'
    volume_spike: dict     # From structure.detect_volume_spike
    key_levels: dict       # From structure.get_key_levels
    candles_5m: pd.DataFrame = field(default_factory=pd.DataFrame)
    candles_15m: pd.DataFrame = field(default_factory=pd.DataFrame)
    scan_reason: str = ""  # Why this ticker was picked


# ──────────────────────────────────────────────
# SCANNER
# ──────────────────────────────────────────────

def scan_market(spy_bias: str = "neutral") -> list[Candidate]:
    """
    Run the full market scan.
    Returns a ranked list of Candidate objects ready for setup detection.
    """
    logger.info(f"Starting market scan — SPY bias: {spy_bias}")

    # Step 1: get top movers from the watchlist
    movers = data_feed.get_top_movers(config.WATCHLIST)

    # Step 2: build candidate pool
    candidate_pool = []

    if spy_bias == "bullish":
        # Focus on gainers and volume spikes
        candidate_pool = movers["gainers"] + movers["volume"]
    elif spy_bias == "bearish":
        # Focus on losers and volume spikes
        candidate_pool = movers["losers"] + movers["volume"]
    else:
        # Neutral: look at high-volume movers both ways
        candidate_pool = movers["volume"]

    # Deduplicate by ticker
    seen = set()
    unique_candidates = []
    for c in candidate_pool:
        if c["ticker"] not in seen:
            seen.add(c["ticker"])
            unique_candidates.append(c)

    # Step 3: deep analysis of each candidate
    results = []
    for item in unique_candidates[:config.TOP_MOVERS_COUNT]:
        ticker = item["ticker"]
        if ticker == "SPY":
            continue   # SPY is used for bias, not as a trade candidate

        candidate = _analyze_candidate(item, spy_bias)
        if candidate is not None:
            results.append(candidate)

    logger.info(f"Scan complete: {len(results)} valid candidates")
    return results


def _analyze_candidate(item: dict, spy_bias: str) -> Candidate | None:
    """
    Fetch candle data and run structural analysis on a single ticker.
    Returns None if the ticker fails basic quality filters.
    """
    ticker = item["ticker"]

    # Basic quality gate
    if item["price"] < config.MIN_STOCK_PRICE:
        logger.debug(f"{ticker}: price too low ({item['price']})")
        return None

    try:
        df_5m  = data_feed.get_candles(ticker, interval="5m",  period="5d")
        df_15m = data_feed.get_candles(ticker, interval="15m", period="5d")
    except Exception as e:
        logger.warning(f"{ticker}: candle fetch failed — {e}")
        return None

    if len(df_5m) < 20 or len(df_15m) < 20:
        logger.debug(f"{ticker}: not enough candle history")
        return None

    # Structural analysis
    trend    = st.get_trend(df_15m)
    vol_info = st.detect_volume_spike(df_5m)
    levels   = st.get_key_levels(df_15m)

    # Filter: trend must loosely align with SPY bias (or be a volume spike)
    aligned = (
        (spy_bias == "bullish" and trend in ("bullish", "neutral")) or
        (spy_bias == "bearish" and trend in ("bearish", "neutral")) or
        (spy_bias == "neutral") or
        vol_info["spike"]   # Always include volume spikes regardless
    )
    if not aligned:
        logger.debug(f"{ticker}: trend {trend} misaligned with SPY {spy_bias}")
        return None

    # Determine why this was picked
    reasons = []
    if item["change_pct"] >= config.MIN_MOVE_PCT:
        reasons.append(f"+{item['change_pct']:.1f}% mover")
    elif item["change_pct"] <= -config.MIN_MOVE_PCT:
        reasons.append(f"{item['change_pct']:.1f}% mover")
    if vol_info["spike"]:
        reasons.append(f"{vol_info['ratio']:.1f}× avg volume")
    if trend != "neutral":
        reasons.append(f"{trend} trend on 15M")

    return Candidate(
        ticker=ticker,
        price=item["price"],
        change_pct=item["change_pct"],
        volume_ratio=item["volume_ratio"],
        trend=trend,
        volume_spike=vol_info,
        key_levels=levels,
        candles_5m=df_5m,
        candles_15m=df_15m,
        scan_reason=", ".join(reasons) if reasons else "watchlist scan",
    )


# ──────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────

def rank_candidates(candidates: list[Candidate]) -> list[Candidate]:
    """
    Sort candidates by a composite quality score.
    Prioritizes volume spikes + strong trends.
    """
    def _score(c: Candidate) -> float:
        s = 0.0
        s += abs(c.change_pct) * 2        # Bigger move = more interesting
        s += (c.volume_ratio - 1) * 10    # Volume above average
        if c.trend != "neutral":
            s += 15
        return s

    return sorted(candidates, key=_score, reverse=True)
