"""
scoring.py — Confidence score engine and setup orchestration
Evaluates every candidate + setup against the 100-point scoring model.
Returns a finalized Setup object ready for alerting.
"""

import pandas as pd
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Optional
import logging

import config
import structure as st
import options as opt

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# SETUP DATA STRUCTURE
# ──────────────────────────────────────────────

@dataclass
class Setup:
    # Identity
    ticker:        str
    direction:     str          # 'call' or 'put'
    setup_type:    str          # 'Breakout', 'Pullback Continuation', 'Reversal'
    market_bias:   str          # 'Bullish', 'Bearish', 'Neutral'

    # Option
    contract:      Optional[opt.OptionContract] = None
    option_stop:   dict = field(default_factory=dict)
    option_targets: dict = field(default_factory=dict)

    # Stock levels
    stock_entry:   str = ""
    stock_stop:    float = 0.0
    stock_target1: float = 0.0
    stock_target2: float = 0.0

    # Score
    score:          int = 0
    score_breakdown: dict = field(default_factory=dict)
    grade:          str = "No trade"

    # Content
    reasons:       list[str] = field(default_factory=list)
    invalidations: list[str] = field(default_factory=list)

    # Meta
    timestamp:     datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_valid:      bool = False
    news_catalyst: bool = False


# ──────────────────────────────────────────────
# SCORING ENGINE
# ──────────────────────────────────────────────

def calculate_score(conditions: dict) -> tuple[int, dict]:
    """
    Score a setup 0–100 using the weighted model from config.

    conditions keys:
        spy_aligned:      bool
        trend_strong:     bool
        volume_spike:     bool
        setup_quality:    int (0–100)
        options_quality:  int (0–100)
        news_catalyst:    bool
        good_timing:      bool
    """
    w = config.SCORE_WEIGHTS
    breakdown = {}
    total = 0

    # SPY alignment (20 pts)
    breakdown["spy_alignment"] = w["spy_alignment"] if conditions.get("spy_aligned") else 0
    total += breakdown["spy_alignment"]

    # Trend quality (15 pts)
    breakdown["trend_quality"] = w["trend_quality"] if conditions.get("trend_strong") else int(w["trend_quality"] * 0.4)
    total += breakdown["trend_quality"]

    # Volume confirmation (15 pts)
    breakdown["volume_confirm"] = w["volume_confirm"] if conditions.get("volume_spike") else 0
    total += breakdown["volume_confirm"]

    # Setup quality (20 pts)
    sq = conditions.get("setup_quality", 0)
    breakdown["setup_quality"] = int(w["setup_quality"] * sq / 100)
    total += breakdown["setup_quality"]

    # Options quality (10 pts)
    oq = conditions.get("options_quality", 0)
    breakdown["options_quality"] = int(w["options_quality"] * oq / 100)
    total += breakdown["options_quality"]

    # News catalyst (10 pts) — bonus, not required
    breakdown["news_catalyst"] = w["news_catalyst"] if conditions.get("news_catalyst") else 0
    total += breakdown["news_catalyst"]

    # Entry timing (10 pts)
    breakdown["entry_timing"] = w["entry_timing"] if conditions.get("good_timing") else int(w["entry_timing"] * 0.3)
    total += breakdown["entry_timing"]

    return min(100, total), breakdown


def get_grade(score: int) -> str:
    if score >= config.GRADE_THRESHOLDS["A+"]:
        return "A+-grade"
    elif score >= config.GRADE_THRESHOLDS["B"]:
        return "B-grade"
    else:
        return "No trade"


# ──────────────────────────────────────────────
# TIMING CHECK
# ──────────────────────────────────────────────

def is_good_timing() -> bool:
    """
    Returns True if we're in a prime trading window (ET).
    Power hour: 9:30–11:00 AM | Close drive: 2:00–4:00 PM
    """
    from datetime import timezone
    from zoneinfo import ZoneInfo  # stdlib 3.9+

    try:
        et = ZoneInfo("America/New_York")
        now_et = datetime.now(et)
        hour = now_et.hour
        minute = now_et.minute

        # Market not open
        if hour < 9 or (hour == 9 and minute < 30):
            return False
        if hour >= 16:
            return False

        # Avoid last 15 minutes of trading
        if hour == 15 and minute >= 45:
            return False

        # Prime windows
        in_power_hour   = (hour == 9 and minute >= 30) or hour == 10
        in_close_drive  = hour >= 14

        return in_power_hour or in_close_drive

    except Exception:
        # zoneinfo unavailable — check UTC approximation (ET = UTC-4/5)
        now_utc = datetime.now(timezone.utc)
        hour_et_approx = (now_utc.hour - 4) % 24
        return (9 <= hour_et_approx < 11) or (14 <= hour_et_approx < 16)


# ──────────────────────────────────────────────
# STOCK STOP / TARGET
# ──────────────────────────────────────────────

def calculate_stock_levels(direction: str, current_price: float,
                             levels: dict, setup_details: dict) -> dict:
    """
    Calculate underlying stock stop loss and price targets.
    Stops are structure-based.
    """
    buffer = current_price * 0.002   # 0.2% buffer

    if direction == "call":
        # Stop below support or breakout level
        broken_level = setup_details.get("broken_level") or setup_details.get("ema20_level")
        support = levels.get("nearest_support") or (current_price * 0.97)
        stock_stop = min(broken_level or support, support) - buffer

        resistance = levels.get("nearest_resistance")
        tp1 = resistance if resistance and resistance > current_price else current_price * 1.03
        tp2 = current_price * 1.06

    else:  # put
        broken_level = setup_details.get("broken_level") or setup_details.get("ema20_level")
        resistance = levels.get("nearest_resistance") or (current_price * 1.03)
        stock_stop = max(broken_level or resistance, resistance) + buffer

        support = levels.get("nearest_support")
        tp1 = support if support and support < current_price else current_price * 0.97
        tp2 = current_price * 0.94

    return {
        "stock_stop": round(stock_stop, 2),
        "stock_tp1": round(tp1, 2),
        "stock_tp2": round(tp2, 2),
        "entry": f"Market / limit near ${current_price:.2f}",
    }


# ──────────────────────────────────────────────
# FULL SETUP EVALUATION
# ──────────────────────────────────────────────

def evaluate_candidate(candidate, setup_result: dict,
                        spy_bias_info: dict) -> Optional[Setup]:
    """
    Given a scanned candidate and detected setup, score and build a Setup object.
    Returns None if score < MIN_ALERT_SCORE.
    """
    from scanner import Candidate

    direction   = setup_result["direction"]     # 'call' or 'put'
    setup_type  = setup_result["setup_type"]
    details     = setup_result["details"]
    spy_bias    = spy_bias_info.get("bias", "neutral")
    current_price = candidate.price

    # ── SPY alignment ──
    spy_aligned = (
        (direction == "call" and spy_bias == "bullish") or
        (direction == "put"  and spy_bias == "bearish") or
        spy_bias_info.get("strength", 0) < 50  # Weak SPY = partial credit
    )

    # ── Volume ──
    vol_info = candidate.volume_spike
    volume_spike = vol_info.get("spike", False)

    # ── Trend ──
    trend_strong = candidate.trend != "neutral"

    # ── Setup quality ──
    setup_quality = _rate_setup_quality(details, setup_type)

    # ── Options selection ──
    trade_style = "momentum" if True else "swing"  # TODO: make configurable
    contract = opt.select_contract(candidate.ticker, direction,
                                    current_price, trade_style)
    options_quality = contract.quality_score() if contract else 0

    # ── No valid contract = reject ──
    if contract is None:
        logger.debug(f"{candidate.ticker}: no valid option contract found")
        return None

    # ── Timing ──
    good_timing = is_good_timing()

    # ── Entry extended check ──
    if details.get("entry_extended"):
        logger.debug(f"{candidate.ticker}: entry overextended — skipping")
        return None

    # ── Score ──
    conditions = {
        "spy_aligned":    spy_aligned,
        "trend_strong":   trend_strong,
        "volume_spike":   volume_spike,
        "setup_quality":  setup_quality,
        "options_quality": options_quality,
        "news_catalyst":  False,    # TODO: integrate news API
        "good_timing":    good_timing,
    }
    score, breakdown = calculate_score(conditions)
    grade = get_grade(score)

    if score < config.MIN_ALERT_SCORE:
        logger.debug(f"{candidate.ticker}: score {score} below threshold")
        return None

    # ── Levels ──
    stock_levels = calculate_stock_levels(
        direction, current_price, candidate.key_levels, details)
    option_stop    = opt.get_option_stop(contract)
    option_targets = opt.get_option_targets(contract)

    # ── Reasons ──
    reasons = _build_reasons(candidate, setup_result, spy_bias_info,
                              contract, vol_info, good_timing)

    # ── Invalidations ──
    invalidations = _build_invalidations(direction, stock_levels,
                                          candidate.key_levels, setup_type)

    return Setup(
        ticker=candidate.ticker,
        direction=direction,
        setup_type=setup_type,
        market_bias=spy_bias.capitalize(),
        contract=contract,
        option_stop=option_stop,
        option_targets=option_targets,
        stock_entry=stock_levels["entry"],
        stock_stop=stock_levels["stock_stop"],
        stock_target1=stock_levels["stock_tp1"],
        stock_target2=stock_levels["stock_tp2"],
        score=score,
        score_breakdown=breakdown,
        grade=grade,
        reasons=reasons,
        invalidations=invalidations,
        is_valid=True,
    )


# ──────────────────────────────────────────────
# HELPERS
# ──────────────────────────────────────────────

def _rate_setup_quality(details: dict, setup_type: str) -> int:
    """Rate setup quality 0–100 based on detail signals."""
    score = 40   # Base for having a detected setup

    if details.get("retest_held"):
        score += 20
    if details.get("confirmation_candle"):
        score += 20
    if details.get("volume_ratio", 1) >= config.VOLUME_SPIKE_MULTIPLIER:
        score += 10
    if details.get("near_ema20") or details.get("near_support"):
        score += 10

    return min(100, score)


def _build_reasons(candidate, setup_result, spy_bias_info,
                   contract, vol_info, good_timing) -> list[str]:
    direction  = setup_result["direction"].upper()
    setup_type = setup_result["setup_type"]
    details    = setup_result["details"]
    spy_bias   = spy_bias_info.get("bias", "neutral").capitalize()

    reasons = []
    reasons.append(f"SPY bias is {spy_bias} — {spy_bias_info.get('details', '')}")
    reasons.append(
        f"{candidate.ticker} in {candidate.trend} trend on 15M "
        f"({candidate.change_pct:+.1f}% today)"
    )
    reasons.append(f"{setup_type} setup detected — {_setup_summary(details, setup_type)}")

    if vol_info.get("spike"):
        reasons.append(
            f"Volume spike: {vol_info['ratio']:.1f}× average "
            f"({int(vol_info['latest_volume'] / 1_000_000):.1f}M shares)"
        )
    if details.get("confirmation_candle"):
        reasons.append("Confirmation candle confirms direction")
    if contract:
        reasons.append(
            f"Option contract liquid: ${contract.strike} {contract.opt_type.upper()} "
            f"exp {contract.expiry} | δ={contract.delta:.2f} | "
            f"mid=${contract.mid:.2f} | vol={contract.volume:,}"
        )
    if good_timing:
        reasons.append("Entry is within a prime trading session window")

    return reasons


def _setup_summary(details: dict, setup_type: str) -> str:
    if setup_type == "Breakout":
        lvl = details.get("broken_level", "")
        return f"broke key level ${lvl:.2f}" if lvl else "breakout confirmed"
    elif setup_type == "Pullback Continuation":
        ema = details.get("ema20_level", "")
        return f"pulled back to EMA20 (${ema:.2f})" if ema else "pullback to support"
    elif setup_type == "Reversal":
        flush = details.get("flush_pct") or details.get("pump_pct", 0)
        return f"{flush:.1f}% flush/pump with reversal confirmation"
    return ""


def _build_invalidations(direction: str, stock_levels: dict,
                          key_levels: dict, setup_type: str) -> list[str]:
    invalids = []
    stop = stock_levels["stock_stop"]

    if direction == "call":
        invalids.append(f"Underlying closes below ${stop:.2f} (structural stop)")
        invalids.append("Bearish candle reclaims the breakout level")
        invalids.append("SPY reverses and breaks below its 20 EMA")
    else:
        invalids.append(f"Underlying closes above ${stop:.2f} (structural stop)")
        invalids.append("Bullish candle reclaims the breakdown level")
        invalids.append("SPY reverses and breaks above its 20 EMA")

    invalids.append(f"Option loses {config.OPTION_STOP_LOSS_PCT:.0f}% of entry value — cut immediately")

    return invalids
