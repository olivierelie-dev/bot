"""
alerts.py — Alert formatting and delivery
Formats Setup objects into the standard alert format and sends to configured channels.
"""

import requests
import logging
from datetime import datetime, timezone
from scoring import Setup
import config

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# FORMATTER
# ──────────────────────────────────────────────

def format_alert(setup: Setup) -> str:
    """Format a Setup into the standard stock/options alert string."""
    direction_str  = "CALL" if setup.direction == "call" else "PUT"
    contract       = setup.contract
    targets        = setup.option_targets
    stop_info      = setup.option_stop
    score_bar      = _make_score_bar(setup.score)
    reasons_str    = "\n".join(f"  • {r}" for r in setup.reasons)
    invalids_str   = "\n".join(f"  • {i}" for i in setup.invalidations)

    opt_block = ""
    if contract:
        opt_block = f"""
──────────────────────────────────────────────
  OPTION CONTRACT
──────────────────────────────────────────────
  Strike:       ${contract.strike:.2f}
  Expiration:   {contract.expiry}  ({contract.dte} DTE)
  Type:         {contract.opt_type.upper()}
  Delta:        {contract.delta:.2f}
  Bid / Ask:    ${contract.bid:.2f} / ${contract.ask:.2f}
  Mid (entry):  ${contract.mid:.2f}
  Volume:       {contract.volume:,}
  Open Int:     {contract.open_interest:,}
  Spread:       {contract.spread_pct:.1f}%"""

    levels_block = f"""
──────────────────────────────────────────────
  LEVELS
──────────────────────────────────────────────
  Stock Entry:  {setup.stock_entry}
  Stock Stop:   ${setup.stock_stop:.2f}
  Stock TP1:    ${setup.stock_target1:.2f}
  Stock TP2:    ${setup.stock_target2:.2f}

  Option Stop:  ${stop_info.get('option_price_stop', 0):.2f}  (−{config.OPTION_STOP_LOSS_PCT:.0f}% from entry)
  Option TP1:   ${targets.get('tp1_price', 0):.2f}  (+{config.TP1_PCT:.0f}%)
  Option TP2:   ${targets.get('tp2_price', 0):.2f}  (+{config.TP2_PCT:.0f}%)"""

    alert = f"""
╔══════════════════════════════════════════════╗
  STOCK ALERT — {direction_str} SETUP
╚══════════════════════════════════════════════╝

  Ticker:       {setup.ticker}
  Market Bias:  {setup.market_bias}
  Confidence:   {setup.score}/100  {score_bar}
  Setup Type:   {setup.setup_type}
  Time (ET):    {_now_et()}

──────────────────────────────────────────────
  REASON
──────────────────────────────────────────────
{reasons_str}
{opt_block}
{levels_block}

──────────────────────────────────────────────
  TRADE PLAN
──────────────────────────────────────────────
  • Take partial at +{config.TP1_PCT:.0f}% option gain (TP1)
  • Scale out at +{config.TP2_PCT:.0f}% option gain (TP2)
  • Let runner go if trend is strong after TP2

──────────────────────────────────────────────
  INVALIDATION
──────────────────────────────────────────────
{invalids_str}

──────────────────────────────────────────────
  TRADE QUALITY:  {setup.grade.upper()}
──────────────────────────────────────────────
"""
    return alert.strip()


def format_no_trade() -> str:
    return f"[{_now_et()}] NO TRADE — Conditions do not meet system requirements."


def _make_score_bar(score: int, width: int = 10) -> str:
    filled = int((score / 100) * width)
    return f"[{'█' * filled}{'░' * (width - filled)}]"


def _now_et() -> str:
    """Return current time in ET as a formatted string."""
    try:
        import pytz_unused
        et = pytz_unused.timezone("America/New_York")
        return datetime.now(et).strftime("%Y-%m-%d %H:%M ET")
    except Exception:
        return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


# ──────────────────────────────────────────────
# DELIVERY
# ──────────────────────────────────────────────

def send_alert(setup: Setup) -> None:
    """Send formatted alert to all configured channels."""
    message = format_alert(setup)
    for channel in config.ALERT_CHANNELS:
        if channel == "console":
            _console(message)
        elif channel == "telegram":
            _telegram(message)
        elif channel == "discord":
            _discord(message)


def send_no_trade() -> None:
    msg = format_no_trade()
    if "console" in config.ALERT_CHANNELS:
        print(msg)
    logger.debug(msg)


def _console(msg: str) -> None:
    print("\n" + "=" * 50)
    print(msg)
    print("=" * 50 + "\n")


def _telegram(msg: str) -> None:
    token   = config.TELEGRAM_BOT_TOKEN
    chat_id = config.TELEGRAM_CHAT_ID
    if not token or not chat_id:
        logger.warning("Telegram not configured")
        return
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    for chunk in [msg[i:i+4000] for i in range(0, len(msg), 4000)]:
        try:
            requests.post(url, json={
                "chat_id": chat_id,
                "text": f"```\n{chunk}\n```",
                "parse_mode": "Markdown",
            }, timeout=10).raise_for_status()
        except Exception as e:
            logger.error(f"Telegram failed: {e}")


def _discord(msg: str) -> None:
    webhook = config.DISCORD_WEBHOOK_URL
    if not webhook:
        logger.warning("Discord not configured")
        return
    try:
        requests.post(webhook, json={"content": f"```\n{msg}\n```"}, timeout=10).raise_for_status()
    except Exception as e:
        logger.error(f"Discord failed: {e}")
