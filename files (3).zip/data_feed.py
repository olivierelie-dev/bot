"""
data_feed.py — Market data ingestion
Supports simulation mode (synthetic) and live mode via yfinance (free).
Optional upgrade paths: Polygon.io, Alpaca.

Returns clean pandas DataFrames with OHLCV + computed fields.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta, timezone
import logging

import config

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# PUBLIC API
# ──────────────────────────────────────────────

def get_candles(ticker: str, interval: str = "5m",
                period: str = "5d") -> pd.DataFrame:
    """
    Fetch OHLCV candles for a ticker.
    interval: '1m', '5m', '15m', '1h', '1d'
    period:   '1d', '5d', '1mo'
    """
    if config.SIMULATION_MODE:
        return _simulated_candles(ticker, interval)
    return _yfinance_candles(ticker, interval, period)


def get_quote(ticker: str) -> dict:
    """
    Return a current snapshot for a ticker.
    Keys: price, change_pct, volume, avg_volume
    """
    if config.SIMULATION_MODE:
        return _simulated_quote(ticker)
    return _yfinance_quote(ticker)


def get_top_movers(universe: list[str] = None) -> dict:
    """
    Scan the universe and return top gainers + losers + volume spikes.
    Returns: {"gainers": [...], "losers": [...], "volume": [...]}
    Each item: {"ticker": str, "change_pct": float, "volume_ratio": float, "price": float}
    """
    if universe is None:
        universe = config.WATCHLIST

    results = []
    for ticker in universe:
        try:
            q = get_quote(ticker)
            results.append({
                "ticker": ticker,
                "price": q["price"],
                "change_pct": q["change_pct"],
                "volume": q["volume"],
                "avg_volume": q["avg_volume"],
                "volume_ratio": q["volume"] / max(q["avg_volume"], 1),
            })
        except Exception as e:
            logger.debug(f"Quote failed for {ticker}: {e}")

    gainers = sorted(
        [r for r in results if r["change_pct"] >= config.MIN_MOVE_PCT],
        key=lambda x: x["change_pct"], reverse=True
    )[:config.TOP_MOVERS_COUNT]

    losers = sorted(
        [r for r in results if r["change_pct"] <= -config.MIN_MOVE_PCT],
        key=lambda x: x["change_pct"]
    )[:config.TOP_MOVERS_COUNT]

    volume_spikes = sorted(
        [r for r in results if r["volume_ratio"] >= config.VOLUME_SPIKE_MULTIPLIER],
        key=lambda x: x["volume_ratio"], reverse=True
    )[:config.TOP_MOVERS_COUNT]

    return {"gainers": gainers, "losers": losers, "volume": volume_spikes}


def get_option_chain(ticker: str, expiry: str = None) -> pd.DataFrame:
    """
    Fetch option chain for a ticker.
    Returns a DataFrame with columns:
      strike, expiry, type (call/put), delta, bid, ask, volume, open_interest
    """
    if config.SIMULATION_MODE:
        return _simulated_option_chain(ticker)
    return _yfinance_option_chain(ticker, expiry)


# ──────────────────────────────────────────────
# SIMULATION MODE
# ──────────────────────────────────────────────

# Realistic base prices for simulation
_SIM_PRICES = {
    "SPY": 520.0, "QQQ": 440.0, "AAPL": 185.0, "TSLA": 260.0,
    "NVDA": 875.0, "META": 510.0, "AMD": 165.0, "AMZN": 190.0,
    "MSFT": 415.0, "GOOG": 175.0, "NFLX": 630.0, "MU": 110.0,
    "MSTR": 175.0, "PLTR": 22.0,
}

_INTERVAL_MINUTES = {"1m": 1, "5m": 5, "15m": 15, "1h": 60, "1d": 390}


def _simulated_candles(ticker: str, interval: str,
                        n_candles: int = 200) -> pd.DataFrame:
    """Generate realistic synthetic OHLCV candles."""
    np.random.seed(abs(hash(ticker)) % (2**31))

    base = _SIM_PRICES.get(ticker, 100.0)
    minutes = _INTERVAL_MINUTES.get(interval, 5)
    volatility = base * 0.0015 * (minutes / 5) ** 0.5

    records = []
    now = datetime.now(timezone.utc).replace(second=0, microsecond=0)
    price = base

    for i in range(n_candles):
        ts = now - timedelta(minutes=minutes * (n_candles - i))
        drift = np.random.normal(0.0002, 0.001)   # Slight upward bias
        move = np.random.normal(drift, volatility)

        open_p = price
        close_p = price + move
        high_p = max(open_p, close_p) + abs(np.random.normal(0, volatility * 0.3))
        low_p  = min(open_p, close_p) - abs(np.random.normal(0, volatility * 0.3))
        vol    = int(np.random.normal(500_000, 150_000))

        records.append({
            "timestamp": ts,
            "open": round(open_p, 2),
            "high": round(high_p, 2),
            "low":  round(low_p, 2),
            "close": round(close_p, 2),
            "volume": max(10_000, vol),
        })
        price = close_p

    df = pd.DataFrame(records).set_index("timestamp")
    return df


def _simulated_quote(ticker: str) -> dict:
    """Return a synthetic quote snapshot."""
    np.random.seed(abs(hash(ticker + str(datetime.now().date()))) % (2**31))
    base = _SIM_PRICES.get(ticker, 100.0)
    change_pct = np.random.normal(0, 2.0)
    price = round(base * (1 + change_pct / 100), 2)
    avg_vol = 10_000_000
    vol_ratio = max(0.3, np.random.normal(1.0, 0.5))

    return {
        "ticker": ticker,
        "price": price,
        "change_pct": round(change_pct, 2),
        "volume": int(avg_vol * vol_ratio),
        "avg_volume": avg_vol,
    }


def _simulated_option_chain(ticker: str) -> pd.DataFrame:
    """Generate a synthetic option chain around current price."""
    np.random.seed(abs(hash(ticker)) % (2**31))
    price = _SIM_PRICES.get(ticker, 100.0)

    rows = []
    today = datetime.now().date()

    for dte in [2, 7, 14, 21]:
        expiry = (today + timedelta(days=dte)).strftime("%Y-%m-%d")
        for strike_offset in [-10, -5, -2, 0, 2, 5, 10]:
            # Round to nearest dollar or 5-dollar increment
            increment = 5 if price > 200 else 1
            strike = round((price + strike_offset * (price * 0.01)) / increment) * increment

            for opt_type in ("call", "put"):
                moneyness = (price - strike) / price
                if opt_type == "put":
                    moneyness = -moneyness

                # Approximate delta from moneyness
                delta = max(0.05, min(0.95, 0.5 + moneyness * 2))
                if opt_type == "put":
                    delta = -(1 - delta)

                mid = max(0.10, price * 0.02 * (dte / 14) ** 0.5 * abs(delta + 0.5))
                spread = mid * 0.08
                bid = round(mid - spread / 2, 2)
                ask = round(mid + spread / 2, 2)

                rows.append({
                    "strike": strike,
                    "expiry": expiry,
                    "dte": dte,
                    "type": opt_type,
                    "delta": round(delta, 2),
                    "bid": bid,
                    "ask": ask,
                    "mid": round(mid, 2),
                    "volume": int(np.random.randint(50, 5000)),
                    "open_interest": int(np.random.randint(200, 20000)),
                    "spread_pct": round(spread / mid * 100, 1),
                })

    return pd.DataFrame(rows)


# ──────────────────────────────────────────────
# LIVE MODE — yfinance
# ──────────────────────────────────────────────

def _yfinance_candles(ticker: str, interval: str,
                       period: str) -> pd.DataFrame:
    try:
        import yfinance as yf
        raw = yf.download(ticker, interval=interval, period=period,
                          progress=False, auto_adjust=True)
        if raw.empty:
            raise ValueError("Empty response")
        raw.columns = [c.lower() for c in raw.columns]
        raw.index.name = "timestamp"
        return raw[["open", "high", "low", "close", "volume"]]
    except Exception as e:
        logger.warning(f"yfinance candles failed for {ticker}: {e}. Using simulation.")
        return _simulated_candles(ticker, interval)


def _yfinance_quote(ticker: str) -> dict:
    try:
        import yfinance as yf
        t = yf.Ticker(ticker)
        info = t.fast_info
        price = float(info.last_price or 0)
        prev  = float(info.previous_close or price)
        change_pct = ((price - prev) / prev * 100) if prev else 0
        return {
            "ticker": ticker,
            "price": round(price, 2),
            "change_pct": round(change_pct, 2),
            "volume": int(info.three_month_average_volume or 0),
            "avg_volume": int(info.three_month_average_volume or 1),
        }
    except Exception as e:
        logger.warning(f"yfinance quote failed for {ticker}: {e}. Using simulation.")
        return _simulated_quote(ticker)


def _yfinance_option_chain(ticker: str, expiry: str = None) -> pd.DataFrame:
    try:
        import yfinance as yf
        t = yf.Ticker(ticker)
        dates = t.options
        if not dates:
            raise ValueError("No option dates")

        target = expiry or dates[0]
        chain = t.option_chain(target)

        def _process(df, opt_type):
            df = df.copy()
            df["type"] = opt_type
            df["expiry"] = target
            # yfinance gives greeks sometimes — use delta if available
            if "delta" not in df.columns:
                df["delta"] = np.nan
            df["spread_pct"] = (df["ask"] - df["bid"]) / (
                (df["ask"] + df["bid"]) / 2 + 0.001) * 100
            dte = (pd.to_datetime(target) - pd.Timestamp.now()).days
            df["dte"] = max(0, dte)
            df["mid"] = (df["bid"] + df["ask"]) / 2
            return df[["strike", "expiry", "dte", "type", "delta",
                        "bid", "ask", "mid", "volume", "openInterest", "spread_pct"]].rename(
                columns={"openInterest": "open_interest"})

        calls = _process(chain.calls, "call")
        puts  = _process(chain.puts, "put")
        return pd.concat([calls, puts], ignore_index=True)

    except Exception as e:
        logger.warning(f"yfinance options failed for {ticker}: {e}. Using simulation.")
        return _simulated_option_chain(ticker)
