"""
options.py — Option contract selection
Selects the best contract given delta, DTE, liquidity, and spread constraints.
"""

import pandas as pd
import numpy as np
import math
from datetime import datetime, date, timedelta
import logging

import config
import data_feed

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────
# CONTRACT DATA STRUCTURE
# ──────────────────────────────────────────────

class OptionContract:
    def __init__(self, ticker: str, row: pd.Series):
        self.ticker        = ticker
        self.strike        = float(row["strike"])
        self.expiry        = str(row["expiry"])
        self.dte           = int(row.get("dte", 0))
        self.opt_type      = str(row["type"])   # 'call' or 'put'
        self.delta         = float(row.get("delta", 0) or 0)
        self.bid           = float(row["bid"])
        self.ask           = float(row["ask"])
        self.mid           = float(row.get("mid", (self.bid + self.ask) / 2))
        self.volume        = int(row.get("volume", 0) or 0)
        self.open_interest = int(row.get("open_interest", 0) or 0)
        self.spread_pct    = float(row.get("spread_pct", 0) or 0)

    def is_liquid(self) -> bool:
        return (
            self.volume >= config.MIN_OPTION_VOLUME and
            self.open_interest >= config.MIN_OPEN_INTEREST and
            self.spread_pct <= config.MAX_BID_ASK_SPREAD_PCT
        )

    def delta_in_range(self) -> bool:
        abs_delta = abs(self.delta)
        return config.OPTION_DELTA_MIN <= abs_delta <= config.OPTION_DELTA_MAX

    def quality_score(self) -> int:
        """Rate contract quality 0–100 for scoring module."""
        score = 0
        if self.delta_in_range():
            score += 40
        if self.volume >= config.MIN_OPTION_VOLUME:
            score += 20
        if self.open_interest >= config.MIN_OPEN_INTEREST:
            score += 20
        if self.spread_pct <= config.MAX_BID_ASK_SPREAD_PCT:
            score += 20
        return score

    def __repr__(self):
        return (
            f"Option({self.ticker} ${self.strike} {self.opt_type.upper()} "
            f"exp={self.expiry} DTE={self.dte} "
            f"δ={self.delta:.2f} mid=${self.mid:.2f} "
            f"vol={self.volume} OI={self.open_interest})"
        )


# ──────────────────────────────────────────────
# CONTRACT SELECTION
# ──────────────────────────────────────────────

def select_contract(ticker: str, direction: str,
                     current_price: float,
                     trade_style: str = "momentum") -> OptionContract | None:
    """
    Select the best option contract for a given ticker and direction.

    direction:   'call' or 'put'
    trade_style: 'momentum' (0–5 DTE) or 'swing' (7–21 DTE)

    Returns the best OptionContract or None if nothing qualifies.
    """
    chain = data_feed.get_option_chain(ticker)
    if chain.empty:
        logger.warning(f"{ticker}: empty option chain")
        return None

    # Filter by type
    opt_type = "call" if direction == "call" else "put"
    filtered = chain[chain["type"] == opt_type].copy()

    if filtered.empty:
        return None

    # DTE filter
    if trade_style == "momentum":
        filtered = filtered[filtered["dte"] <= config.MOMENTUM_DTE_MAX]
    else:
        filtered = filtered[
            (filtered["dte"] >= config.SWING_DTE_MIN) &
            (filtered["dte"] <= config.SWING_DTE_MAX)
        ]

    if filtered.empty:
        logger.debug(f"{ticker}: no contracts in DTE range for {trade_style}")
        return None

    # Delta filter — use absolute delta
    filtered = filtered.copy()
    filtered["abs_delta"] = filtered["delta"].abs()
    filtered = filtered[
        (filtered["abs_delta"] >= config.OPTION_DELTA_MIN) &
        (filtered["abs_delta"] <= config.OPTION_DELTA_MAX)
    ]

    if filtered.empty:
        logger.debug(f"{ticker}: no contracts in delta range")
        return None

    # Liquidity filter
    filtered = filtered[
        (filtered["volume"] >= config.MIN_OPTION_VOLUME) |
        (filtered["open_interest"] >= config.MIN_OPEN_INTEREST)
    ]

    if filtered.empty:
        logger.debug(f"{ticker}: no liquid contracts")
        return None

    # Spread filter
    filtered = filtered[
        filtered["spread_pct"] <= config.MAX_BID_ASK_SPREAD_PCT
    ]

    if filtered.empty:
        logger.debug(f"{ticker}: all contracts have wide spreads")
        return None

    # Select: prefer delta closest to 0.45 (sweet spot) with good liquidity
    filtered["delta_score"] = (filtered["abs_delta"] - 0.45).abs()
    filtered["liquidity_score"] = (
        filtered["volume"] / filtered["volume"].max() * 0.5 +
        filtered["open_interest"] / filtered["open_interest"].max() * 0.5
    )
    filtered["composite"] = (
        (1 - filtered["delta_score"] / 0.2) * 0.6 +
        filtered["liquidity_score"] * 0.4
    )

    best_row = filtered.sort_values("composite", ascending=False).iloc[0]
    contract = OptionContract(ticker, best_row)

    logger.info(f"Selected: {contract}")
    return contract


# ──────────────────────────────────────────────
# STOP LOSS FOR OPTIONS
# ──────────────────────────────────────────────

def get_option_stop(contract: OptionContract) -> dict:
    """
    Calculate stop loss for an option position.
    Two stops:
      1. Structure stop: based on underlying price invalidation
      2. Option price stop: cut if option loses X% of value
    """
    option_stop_price = round(contract.mid * (1 - config.OPTION_STOP_LOSS_PCT / 100), 2)

    return {
        "option_price_stop": option_stop_price,
        "stop_loss_pct": config.OPTION_STOP_LOSS_PCT,
        "description": f"Cut position if option drops to ${option_stop_price:.2f} "
                       f"(−{config.OPTION_STOP_LOSS_PCT:.0f}% from entry)",
    }


# ──────────────────────────────────────────────
# TAKE PROFIT FOR OPTIONS
# ──────────────────────────────────────────────

def get_option_targets(contract: OptionContract) -> dict:
    """Calculate TP1 (+50%) and TP2 (+100%) option price targets."""
    tp1 = round(contract.mid * (1 + config.TP1_PCT / 100), 2)
    tp2 = round(contract.mid * (1 + config.TP2_PCT / 100), 2)

    return {
        "tp1_price": tp1,
        "tp2_price": tp2,
        "tp1_pct": config.TP1_PCT,
        "tp2_pct": config.TP2_PCT,
    }
