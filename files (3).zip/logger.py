"""logger.py — Centralized logging configuration"""

import logging
import sys


def setup_logging(level: str = "INFO", log_file: str = "bot.log") -> None:
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)-20s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(getattr(logging, level.upper(), logging.INFO))
    console.setFormatter(formatter)

    file_h = logging.FileHandler(log_file, encoding="utf-8")
    file_h.setLevel(logging.DEBUG)
    file_h.setFormatter(formatter)

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.handlers.clear()
    root.addHandler(console)
    root.addHandler(file_h)

    for noisy in ("urllib3", "requests", "yfinance", "peewee"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
