# Stock + Options Alert Bot

> **Analysis-only alert system for stocks and options. No auto-execution. No broker integration. Alerts only.**

![Python](https://img.shields.io/badge/python-3.11%2B-blue?style=flat-square)
![License](https://img.shields.io/badge/license-MIT-green?style=flat-square)
![Mode](https://img.shields.io/badge/trading-alerts%20only-orange?style=flat-square)
![Status](https://img.shields.io/badge/version-1.0.0-brightgreen?style=flat-square)
![Data](https://img.shields.io/badge/data-yfinance%20%2F%20Polygon-lightgrey?style=flat-square)

A clean, modular Python bot that scans the market, scores stock setups against a structured strategy, selects quality option contracts, and sends high-conviction trade alerts for **manual review**. You decide whether to take the trade.

---

## ⚠️ Disclaimer

This software is for **educational and informational purposes only**. It does not constitute financial advice. Options trading carries significant risk including the potential loss of the entire premium paid. Never risk money you cannot afford to lose.

---

## Features

- **SPY bias engine** — 5M EMA position + 15M structure + opening momentum
- **Market scanner** — top gainers, losers, and unusual volume from your watchlist
- **3 setup types** — Breakout, Pullback Continuation, Reversal
- **Smart options selection** — filters by delta (0.30–0.60), DTE, volume, OI, and spread
- **100-point confidence scoring** — alerts only fire at ≥ 70
- **Structure-based stops** — below support for calls, above resistance for puts
- **Option targets** — TP1 at +50%, TP2 at +100% option gain
- **Simulation mode** — full synthetic data, no API key needed
- **Live mode** — yfinance (free), optional Polygon.io / Alpaca upgrade
- **Delivery** — console, Telegram, Discord
- **Trade journal** — SQLite log with manual outcome tracking

---

## Project Structure

```
stock-options-alert-bot/
├── main.py           ← Entry point and scan loop
├── config.py         ← All thresholds and settings (tweak here)
├── data_feed.py      ← OHLCV + option chain ingestion (sim + live)
├── spy_bias.py       ← SPY market direction engine
├── structure.py      ← Per-stock trend, swing levels, volume
├── scanner.py        ← Watchlist scanner and candidate ranking
├── setups.py         ← Breakout / Pullback / Reversal detection
├── options.py        ← Contract selection, stops, targets
├── scoring.py        ← Confidence score engine + Setup object
├── alerts.py         ← Alert formatting and channel delivery
├── journal.py        ← SQLite trade log and performance stats
├── logger.py         ← Dual console + file logging
├── requirements.txt
├── .env.example
├── CHANGELOG.md
└── CONTRIBUTING.md
```

---

## Quickstart

### 1. Clone and install

```bash
git clone https://github.com/YOUR_USERNAME/stock-options-alert-bot.git
cd stock-options-alert-bot

python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate

pip install -r requirements.txt
```

### 2. Configure

```bash
cp .env.example .env
# .env is git-ignored — your keys never leave your machine
```

### 3. Run in simulation mode (no API key needed)

```bash
# Single scan with verbose output
python main.py --mode once --verbose

# Continuous loop — scans every 60 seconds
python main.py --mode run

# Journal performance stats
python main.py --mode stats
```

---

## Configuration

All parameters live in `config.py`:

| Setting | Default | Description |
|---|---|---|
| `SIMULATION_MODE` | `True` | `False` to use live yfinance data |
| `WATCHLIST` | 14 tickers | Tickers to scan |
| `MIN_ALERT_SCORE` | `70` | Minimum score to send alert |
| `OPTION_DELTA_MIN/MAX` | `0.30 / 0.60` | Delta range for contracts |
| `MOMENTUM_DTE_MAX` | `5` | Max DTE for momentum trades |
| `SWING_DTE_MIN/MAX` | `7 / 21` | DTE range for swing trades |
| `VOLUME_SPIKE_MULTIPLIER` | `1.5` | Volume vs average threshold |
| `OPTION_STOP_LOSS_PCT` | `35` | Cut option at −35% |
| `TP1_PCT / TP2_PCT` | `50 / 100` | Option gain targets |
| `SCAN_INTERVAL_SECONDS` | `60` | Loop frequency |

---

## Live Data Setup

yfinance works out of the box with no API key:

```python
# config.py
SIMULATION_MODE = False
```

For higher rate limits and real-time data, add to `.env`:

```
POLYGON_API_KEY=your_key      # polygon.io — free tier available
ALPACA_API_KEY=your_key       # alpaca.markets — free paper trading
ALPACA_API_SECRET=your_secret
```

---

## Alert Delivery

### Telegram

1. Create a bot via [@BotFather](https://t.me/BotFather) → copy the token
2. Get your chat ID via [@userinfobot](https://t.me/userinfobot)
3. Add to `.env`:
   ```
   TELEGRAM_BOT_TOKEN=your_token
   TELEGRAM_CHAT_ID=your_chat_id
   ```
4. In `config.py`: `ALERT_CHANNELS = ["console", "telegram"]`

### Discord

1. Server **Settings → Integrations → Webhooks → New Webhook** → copy URL
2. Add to `.env`: `DISCORD_WEBHOOK_URL=your_url`
3. In `config.py`: `ALERT_CHANNELS = ["console", "discord"]`

---

## Strategy Overview

```
SPY Bias (5M + 15M)
  └─ Bullish / Bearish / Neutral
       └─ Scan Watchlist for Movers + Volume Spikes
            └─ Per-Stock Structure Analysis
                 └─ Setup Detected (Breakout / Pullback / Reversal)
                      └─ Volume Confirmed
                           └─ Option Contract Selected (δ 0.30–0.60)
                                └─ Score ≥ 70
                                     └─ ALERT SENT ✓
```

### Confidence Scoring (100 pts)

| Condition | Points |
|---|---|
| SPY alignment | 20 |
| Trend quality | 15 |
| Volume confirmation | 15 |
| Setup quality | 20 |
| Options quality (delta/liquidity) | 10 |
| News catalyst | 10 |
| Entry timing (power hour / close) | 10 |

**Alert grades:** A+ (85–100) · B (70–84) · No alert (< 70)

### Setup Types

| Setup | Call Trigger | Put Trigger |
|---|---|---|
| **Breakout** | Breaks resistance + volume + retest holds | Breaks support + volume + retest fails |
| **Pullback** | Uptrend → EMA/support dip → bullish candle | Downtrend → EMA/resistance pop → bearish candle |
| **Reversal** | Flush + bounce + reclaim key level | Pump + rejection + breakdown begins |

---

## Sample Alert

```
╔══════════════════════════════════════════════╗
  STOCK ALERT — CALL SETUP
╚══════════════════════════════════════════════╝

  Ticker:       NVDA
  Market Bias:  Bullish
  Confidence:   84/100  [████████░░]
  Setup Type:   Breakout
  Time (ET):    2026-03-22 10:14 ET

──────────────────────────────────────────────
  REASON
──────────────────────────────────────────────
  • SPY bias is Bullish — 5M EMA: above | 15M structure: bullish
  • NVDA in bullish trend on 15M (+3.2% today)
  • Breakout setup detected — broke key level $878.00
  • Volume spike: 2.3× average (48.1M shares)
  • Confirmation candle confirms direction
  • Option contract liquid: $880 CALL exp 2026-03-27 | δ=0.44 | mid=$9.20 | vol=3,241
  • Entry is within a prime trading session window

──────────────────────────────────────────────
  OPTION CONTRACT
──────────────────────────────────────────────
  Strike:       $880.00
  Expiration:   2026-03-27  (5 DTE)
  Type:         CALL
  Delta:        0.44
  Bid / Ask:    $8.90 / $9.50
  Mid (entry):  $9.20
  Volume:       3,241
  Open Int:     18,500
  Spread:       6.5%

──────────────────────────────────────────────
  LEVELS
──────────────────────────────────────────────
  Stock Entry:  Market / limit near $879.50
  Stock Stop:   $868.00
  Stock TP1:    $892.00
  Stock TP2:    $910.00

  Option Stop:  $5.98  (−35% from entry)
  Option TP1:   $13.80  (+50%)
  Option TP2:   $18.40  (+100%)

──────────────────────────────────────────────
  TRADE PLAN
──────────────────────────────────────────────
  • Take partial at +50% option gain (TP1)
  • Scale out at +100% option gain (TP2)
  • Let runner go if trend is strong after TP2

──────────────────────────────────────────────
  INVALIDATION
──────────────────────────────────────────────
  • Underlying closes below $868.00 (structural stop)
  • Bearish candle reclaims the breakout level
  • SPY reverses and breaks below its 20 EMA
  • Option loses 35% of entry value — cut immediately

──────────────────────────────────────────────
  TRADE QUALITY:  B-GRADE
──────────────────────────────────────────────
```

---

## Trade Journal

Every alert is logged automatically. Add outcomes manually after reviewing:

```python
from journal import update_outcome

# Record what happened to alert ID 7
update_outcome(alert_id=7, outcome="win_tp1", outcome_pct=52.0,
               notes="Clean breakout, held support on retest")
```

View performance:

```bash
python main.py --mode stats
```

---

## Roadmap

- [ ] Real delta from live option chain (Polygon / Tastytrade API)
- [ ] News catalyst integration (Benzinga, Unusual Whales)
- [ ] Earnings filter — avoid trading into earnings
- [ ] IV rank / IV percentile filter for option premium quality
- [ ] FVG and order block detection
- [ ] Multi-timeframe confirmation (1M entry trigger)
- [ ] Backtesting against historical yfinance data
- [ ] Web dashboard (FastAPI + React)
- [ ] Telegram inline buttons for outcome logging
- [ ] Unified dashboard combining EUR/USD + Stock alerts

---

## Sister Project

This bot is designed to eventually merge with the **EUR/USD Alert Bot**:

> [eurusd-alert-bot](https://github.com/YOUR_USERNAME/eurusd-alert-bot) — Forex alerts using the same modular architecture

Both share the same philosophy: rule-based, transparent, selective, no auto-execution.

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). PRs welcome against the `dev` branch.

**Auto-execution and broker order placement will never be added by design.**

---

## License

[MIT](LICENSE)
