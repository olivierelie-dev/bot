# Contributing

## Getting Started

```bash
git clone https://github.com/YOUR_USERNAME/stock-options-alert-bot.git
cd stock-options-alert-bot
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python main.py --mode once --verbose
```

## Branching

- `main` — stable
- `dev` — active development
- Feature branches: `feature/your-feature`
- Fixes: `fix/short-description`

## Submitting Changes

1. Fork and branch from `dev`
2. Keep logic rule-based and readable
3. Test in simulation: `python main.py --mode once --verbose`
4. Open a PR against `dev` with a clear description

## Ideas for Contribution

- Polygon.io / Alpaca data integration
- Greeks-based option selection (real delta from chain)
- News catalyst integration (Benzinga, Unusual Whales)
- FVG and order block detection
- Web dashboard
- Backtesting against historical data

## Important

**Never add auto-execution or broker order placement.** Alerts only.
