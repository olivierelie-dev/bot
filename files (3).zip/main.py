"""
main.py — Entry point for the Stock + Options Alert Bot

⚠️  This bot NEVER places trades. Analysis and alerts only.

Usage:
  python main.py --mode run         # Continuous loop
  python main.py --mode once        # Single scan cycle
  python main.py --mode stats       # Journal statistics
"""

import time
import logging
import argparse
from datetime import datetime, timezone

import config
import logger as log_setup
import spy_bias as sb
import scanner
import setups
import scoring
import alerts
import journal


def run_once(verbose: bool = False) -> None:
    """Execute one complete scan → score → alert cycle."""
    log = logging.getLogger("main")
    now = datetime.now(timezone.utc)
    log.info(f"Scan cycle — {now.strftime('%Y-%m-%d %H:%M UTC')}")

    # ── 1. Determine SPY market direction ──
    spy = sb.get_spy_bias()
    log.info(f"SPY: {spy['bias'].upper()} | {spy['details']}")

    if spy["bias"] == "neutral" and not config.SIMULATION_MODE:
        log.info("SPY neutral — reduced scan scope")

    # ── 2. Scan for candidates ──
    candidates = scanner.scan_market(spy["bias"])
    candidates = scanner.rank_candidates(candidates)

    if not candidates:
        alerts.send_no_trade()
        return

    log.info(f"Candidates: {[c.ticker for c in candidates]}")

    # ── 3. Evaluate each candidate ──
    alerted = 0
    for candidate in candidates:
        if verbose:
            log.info(
                f"  {candidate.ticker}: trend={candidate.trend} "
                f"vol={candidate.volume_spike.get('ratio', 1):.1f}× "
                f"reason='{candidate.scan_reason}'"
            )

        # Detect setup
        setup_result = setups.run_all_setups(candidate, spy["bias"])
        if setup_result is None:
            log.debug(f"{candidate.ticker}: no setup detected")
            continue

        log.info(
            f"{candidate.ticker}: {setup_result['setup_type']} "
            f"{setup_result['direction'].upper()} detected"
        )

        # Score and build Setup object
        setup_obj = scoring.evaluate_candidate(candidate, setup_result, spy)
        if setup_obj is None:
            continue

        log.info(
            f"{candidate.ticker}: score={setup_obj.score} grade={setup_obj.grade}"
        )

        # Alert + journal
        alerts.send_alert(setup_obj)
        journal.log_alert(setup_obj)
        alerted += 1

    if alerted == 0:
        alerts.send_no_trade()


def run_loop() -> None:
    """Continuous scan loop."""
    log = logging.getLogger("main")
    log.info(
        f"Stock + Options Alert Bot starting — "
        f"{'SIMULATION' if config.SIMULATION_MODE else 'LIVE'} mode"
    )
    log.info(f"Watchlist: {config.WATCHLIST}")
    log.info("⚠️  No trades are ever placed automatically.")

    journal.init_db()

    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            log.info("Bot stopped.")
            break
        except Exception as e:
            log.error(f"Unexpected error: {e}", exc_info=True)

        log.debug(f"Sleeping {config.SCAN_INTERVAL_SECONDS}s...")
        time.sleep(config.SCAN_INTERVAL_SECONDS)


def show_stats() -> None:
    journal.init_db()
    stats = journal.get_stats()
    print("\n── Journal Statistics ──────────────")
    for k, v in stats.items():
        print(f"  {k:<22}: {v}")
    print("─────────────────────────────────────\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Stock + Options Alert Bot — analysis only, no execution"
    )
    parser.add_argument(
        "--mode", choices=["run", "once", "stats"], default="run",
        help="run=loop | once=single cycle | stats=journal stats"
    )
    parser.add_argument("--verbose",    action="store_true")
    parser.add_argument("--log-level",  default="INFO")
    args = parser.parse_args()

    log_setup.setup_logging(level=args.log_level)

    if args.mode == "run":
        run_loop()
    elif args.mode == "once":
        journal.init_db()
        run_once(verbose=args.verbose)
    elif args.mode == "stats":
        show_stats()
