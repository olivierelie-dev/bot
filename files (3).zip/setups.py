"""
setups.py — Setup pattern detection
Identifies Breakout, Pullback Continuation, and Reversal setups.
Each detector returns a standardized result dict.
"""

import pandas as pd
import numpy as np
import logging

import config
import structure as st

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────
# SHARED RESULT SCHEMA
# ──────────────────────────────────────────────

def _no_setup() -> dict:
    return {"detected": False, "direction": None, "details": {}}


# ──────────────────────────────────────────────
# SETUP 1: BREAKOUT
# ──────────────────────────────────────────────

def detect_breakout(df_5m: pd.DataFrame,
                     df_15m: pd.DataFrame,
                     levels: dict,
                     spy_bias: str) -> dict:
    """
    Detect a breakout above resistance (call) or below support (put).

    Call breakout:
      - Price consolidates near resistance
      - Breaks above on volume
      - Retest holds

    Put breakdown:
      - Price consolidates near support
      - Breaks below on volume
      - Retest fails
    """
    if df_5m.empty or df_15m.empty:
        return _no_setup()

    current_price = float(df_5m["close"].iloc[-1])
    vol_info      = st.detect_volume_spike(df_5m)

    # ── CALL BREAKOUT ──
    resistance = levels.get("nearest_resistance")
    if (resistance and spy_bias != "bearish" and
            _is_breakout_above(df_5m, resistance)):

        # Consolidation check: price ranged under resistance for N candles
        consol = _count_consolidation_candles(df_5m, resistance, "below")
        retest = _retest_holds(df_5m, resistance, "above")

        if consol >= config.MIN_CONSOLIDATION_CANDLES and vol_info["spike"]:
            confirm = st.get_confirmation_candle(df_5m, "call")
            extended = st.is_entry_extended(df_5m, "call")
            return {
                "detected": True,
                "direction": "call",
                "setup_type": "Breakout",
                "details": {
                    "broken_level": resistance,
                    "consolidation_candles": consol,
                    "volume_ratio": vol_info["ratio"],
                    "retest_held": retest,
                    "confirmation_candle": confirm,
                    "entry_extended": extended,
                },
            }

    # ── PUT BREAKDOWN ──
    support = levels.get("nearest_support")
    if (support and spy_bias != "bullish" and
            _is_breakdown_below(df_5m, support)):

        consol  = _count_consolidation_candles(df_5m, support, "above")
        retest  = _retest_holds(df_5m, support, "below")

        if consol >= config.MIN_CONSOLIDATION_CANDLES and vol_info["spike"]:
            confirm  = st.get_confirmation_candle(df_5m, "put")
            extended = st.is_entry_extended(df_5m, "put")
            return {
                "detected": True,
                "direction": "put",
                "setup_type": "Breakout",
                "details": {
                    "broken_level": support,
                    "consolidation_candles": consol,
                    "volume_ratio": vol_info["ratio"],
                    "retest_held": retest,
                    "confirmation_candle": confirm,
                    "entry_extended": extended,
                },
            }

    return _no_setup()


# ──────────────────────────────────────────────
# SETUP 2: PULLBACK CONTINUATION
# ──────────────────────────────────────────────

def detect_pullback(df_5m: pd.DataFrame,
                     df_15m: pd.DataFrame,
                     levels: dict,
                     spy_bias: str) -> dict:
    """
    Detect a healthy pullback in a trending market.

    Call: uptrend → pulls back to EMA/support → holds → bullish candle
    Put:  downtrend → pops to EMA/resistance → rejects → bearish candle
    """
    if df_5m.empty or df_15m.empty:
        return _no_setup()

    trend   = st.get_trend(df_15m)
    df_ema  = st.add_emas(df_5m)
    last    = df_ema.iloc[-1]
    current = float(last["close"])
    ema20   = float(last["ema20"])

    vol_info = st.detect_volume_spike(df_5m)

    # ── CALL PULLBACK ──
    if trend == "bullish" and spy_bias != "bearish":
        # Price should be pulling back toward EMA20
        near_ema     = abs(current - ema20) / ema20 * 100 <= config.PULLBACK_EMA_BUFFER_PCT
        support      = levels.get("nearest_support")
        near_support = (
            support and abs(current - support) / current * 100
            <= config.PULLBACK_EMA_BUFFER_PCT * 2
        )

        if near_ema or near_support:
            # Check that prior candles show a dip
            prior_5 = df_5m.tail(5)
            pulled_back = prior_5["low"].min() < float(df_5m.tail(15)["close"].quantile(0.4))
            confirm    = st.get_confirmation_candle(df_5m, "call")
            extended   = st.is_entry_extended(df_5m, "call")

            if pulled_back and confirm and not extended:
                return {
                    "detected": True,
                    "direction": "call",
                    "setup_type": "Pullback Continuation",
                    "details": {
                        "trend": trend,
                        "near_ema20": near_ema,
                        "near_support": near_support,
                        "ema20_level": round(ema20, 2),
                        "volume_ratio": vol_info["ratio"],
                        "confirmation_candle": confirm,
                        "entry_extended": extended,
                    },
                }

    # ── PUT PULLBACK ──
    if trend == "bearish" and spy_bias != "bullish":
        near_ema    = abs(current - ema20) / ema20 * 100 <= config.PULLBACK_EMA_BUFFER_PCT
        resistance  = levels.get("nearest_resistance")
        near_resist = (
            resistance and abs(current - resistance) / current * 100
            <= config.PULLBACK_EMA_BUFFER_PCT * 2
        )

        if near_ema or near_resist:
            prior_5    = df_5m.tail(5)
            popped_up  = prior_5["high"].max() > float(df_5m.tail(15)["close"].quantile(0.6))
            confirm    = st.get_confirmation_candle(df_5m, "put")
            extended   = st.is_entry_extended(df_5m, "put")

            if popped_up and confirm and not extended:
                return {
                    "detected": True,
                    "direction": "put",
                    "setup_type": "Pullback Continuation",
                    "details": {
                        "trend": trend,
                        "near_ema20": near_ema,
                        "near_resistance": near_resist,
                        "ema20_level": round(ema20, 2),
                        "volume_ratio": vol_info["ratio"],
                        "confirmation_candle": confirm,
                        "entry_extended": extended,
                    },
                }

    return _no_setup()


# ──────────────────────────────────────────────
# SETUP 3: REVERSAL
# ──────────────────────────────────────────────

def detect_reversal(df_5m: pd.DataFrame,
                     df_15m: pd.DataFrame,
                     levels: dict,
                     spy_bias: str) -> dict:
    """
    Detect a sharp reversal — flush + bounce (call) or pump + rejection (put).
    Higher bar: requires strong volume + reclaim of a key level.
    """
    if df_5m.empty or len(df_5m) < 20:
        return _no_setup()

    vol_info = st.detect_volume_spike(df_5m)
    recent   = df_5m.tail(10)

    # ── CALL REVERSAL — flush + bounce ──
    if spy_bias != "bearish":
        # Sharp selloff: last N candles show a large down move
        high_5  = float(recent["high"].max())
        low_5   = float(recent["low"].min())
        last_c  = float(df_5m["close"].iloc[-1])
        flush_pct = (high_5 - low_5) / high_5 * 100

        # Bounce: close recovers significantly from the low
        bounce_pct = (last_c - low_5) / (high_5 - low_5 + 0.001) * 100

        support  = levels.get("nearest_support")
        reclaimed = support and last_c > support

        if (flush_pct >= 2.0 and bounce_pct >= 50 and
                vol_info["spike"] and reclaimed):
            confirm = st.get_confirmation_candle(df_5m, "call")
            return {
                "detected": True,
                "direction": "call",
                "setup_type": "Reversal",
                "details": {
                    "flush_pct": round(flush_pct, 2),
                    "bounce_pct": round(bounce_pct, 1),
                    "reclaimed_level": support,
                    "volume_ratio": vol_info["ratio"],
                    "confirmation_candle": confirm,
                    "entry_extended": False,
                },
            }

    # ── PUT REVERSAL — pump + rejection ──
    if spy_bias != "bullish":
        high_5  = float(recent["high"].max())
        low_5   = float(recent["low"].min())
        last_c  = float(df_5m["close"].iloc[-1])
        pump_pct = (high_5 - low_5) / low_5 * 100

        # Rejection: close sells off significantly from the high
        reject_pct = (high_5 - last_c) / (high_5 - low_5 + 0.001) * 100

        resistance = levels.get("nearest_resistance")
        rejected   = resistance and last_c < resistance

        if (pump_pct >= 2.0 and reject_pct >= 50 and
                vol_info["spike"] and rejected):
            confirm = st.get_confirmation_candle(df_5m, "put")
            return {
                "detected": True,
                "direction": "put",
                "setup_type": "Reversal",
                "details": {
                    "pump_pct": round(pump_pct, 2),
                    "rejection_pct": round(reject_pct, 1),
                    "rejected_at": resistance,
                    "volume_ratio": vol_info["ratio"],
                    "confirmation_candle": confirm,
                    "entry_extended": False,
                },
            }

    return _no_setup()


# ──────────────────────────────────────────────
# PRIVATE HELPERS
# ──────────────────────────────────────────────

def _is_breakout_above(df: pd.DataFrame, level: float,
                        tolerance_pct: float = 0.3) -> bool:
    """Returns True if the last close is above the level by a margin."""
    last = float(df["close"].iloc[-1])
    return last > level * (1 + tolerance_pct / 100)


def _is_breakdown_below(df: pd.DataFrame, level: float,
                         tolerance_pct: float = 0.3) -> bool:
    last = float(df["close"].iloc[-1])
    return last < level * (1 - tolerance_pct / 100)


def _count_consolidation_candles(df: pd.DataFrame, level: float,
                                   side: str, lookback: int = 20) -> int:
    """Count candles that stayed on one side of a level (consolidation)."""
    recent = df.tail(lookback)
    if side == "below":
        return int((recent["close"] < level).sum())
    else:
        return int((recent["close"] > level).sum())


def _retest_holds(df: pd.DataFrame, level: float, side: str,
                   n: int = 5) -> bool:
    """
    After a break, check if a retest of the level held.
    side: 'above' = we broke above and need price to stay above after retest
          'below' = we broke below and need price to stay below
    """
    recent = df.tail(n)
    if side == "above":
        # Price dipped near level but closed back above
        touched = (recent["low"] <= level * 1.002).any()
        held    = float(recent["close"].iloc[-1]) > level
        return touched and held
    else:
        touched = (recent["high"] >= level * 0.998).any()
        held    = float(recent["close"].iloc[-1]) < level
        return touched and held


def run_all_setups(candidate, spy_bias: str) -> dict | None:
    """
    Run all three setup detectors on a candidate.
    Returns the best setup found, or None.
    Priority: Breakout → Pullback → Reversal (Reversal is harder to trade).
    """
    df_5m  = candidate.candles_5m
    df_15m = candidate.candles_15m
    levels = candidate.key_levels

    for detector in [detect_breakout, detect_pullback, detect_reversal]:
        result = detector(df_5m, df_15m, levels, spy_bias)
        if result["detected"]:
            return result

    return None
