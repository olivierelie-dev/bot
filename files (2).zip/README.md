# EUR/USD Alert Bot

> **Analysis-only trading alert system for EUR/USD. No auto-execution. No broker integration. Alerts only.**

![Python](https://img.shields.io/badge/python-3.11%2B-blue?style=flat-square)
![License](https://img.shields.io/badge/license-MIT-green?style=flat-square)
![Mode](https://img.shields.io/badge/trading-alerts%20only-orange?style=flat-square)
![Status](https://img.shields.io/badge/version-1.0.0-brightgreen?style=flat-square)

A clean, modular Python bot that monitors EUR/USD market conditions, scores setups against a structured discretionary strategy, and sends high-quality trade alerts for **manual review**. You decide whether to take the trade.

---

## ⚠️ Disclaimer

This software is for **educational and informational purposes only**. It does not constitute financial advice. Trading forex carries significant risk. Never risk money you cannot afford to lose. Past alert quality does not guarantee future results.

---

## Features

- **7-step strategy engine** — bias → zones → sweep → BOS → retest → RR → news
- **4 timeframe analysis** — 4H macro bias, 1H structure, 15M confirmation, 5M entry
- **3 setup types** — Liquidity Sweep Reversal, Break & Retest, Session Expansion
- **100-point confidence scoring** — only alerts for score ≥ 70
- **News calendar filter** — hard blocks 15 min before/after CPI, NFP, FOMC, ECB, and more
- **Session filter** — prioritizes London (08–11 UTC) and New York (13–16 UTC) windows
- **Risk:Reward enforcement** — minimum 1.8R, rejects low-quality setups automatically
- **Delivery** — console, Telegram bot, Discord webhook
- **Trade journal** — SQLite log of every alert with manual outcome tracking
- **Simulation mode** — test without live data or API keys

---

## Project Structure

```
eurusd-alert-bot/
├── main.py           ← Entry point and main loop
├── config.py         ← All thresholds and settings (tweak here)
├── data_feed.py      ← Candle ingestion: simulation + Alpha Vantage live
├── indicators.py     ← EMA 20/50, trend direction, candle classification
├── structure.py      ← Swing detection, Break of Structure, retest logic
├── zones.py          ← Supply/demand zones, liquidity sweep detection
├── sessions.py       ← London/NY session ranges and timing
├── news_filter.py    ← High-impact economic calendar filter
├── scoring.py        ← Setup evaluation and confidence score engine
├── alerts.py         ← Alert formatting and channel delivery
├── journal.py        ← SQLite trade log and performance stats
├── logger.py         ← Dual console + file logging
├── requirements.txt
├── .env.example
├── CHANGELOG.md
└── CONTRIBUTING.md
```

---

## Quickstart

### 1. Clone and install

```bash
git clone https://github.com/YOUR_USERNAME/eurusd-alert-bot.git
cd eurusd-alert-bot

python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate

pip install -r requirements.txt
```

### 2. Configure

```bash
cp .env.example .env
# .env is git-ignored — your keys never leave your machine
```

### 3. Run in simulation mode (no API key needed)

```bash
# Single analysis cycle with verbose output
python main.py --mode once --verbose

# Continuous loop — scans every 60 seconds
python main.py --mode run

# View journal performance stats
python main.py --mode stats
```

---

## Configuration

All strategy parameters live in `config.py`. The most important knobs:

| Setting | Default | Description |
|---|---|---|
| `SIMULATION_MODE` | `True` | `False` to use live Alpha Vantage data |
| `MIN_ALERT_SCORE` | `70` | Minimum confidence score to send alert |
| `MIN_RR` | `1.8` | Minimum risk:reward ratio |
| `PREFERRED_RR` | `2.0` | RR threshold for bonus score points |
| `SWING_LOOKBACK` | `5` | Candles each side for swing detection |
| `SWEEP_TOLERANCE_PIPS` | `3` | How far beyond swing qualifies as a sweep |
| `NEWS_BLOCK_BEFORE_MIN` | `15` | Block alerts N minutes before news |
| `NEWS_BLOCK_AFTER_MIN` | `15` | Block alerts N minutes after news |
| `SCAN_INTERVAL_SECONDS` | `60` | How often to run the analysis loop |

---

## Live Data Setup

1. Get a free API key at [alphavantage.co](https://www.alphavantage.co/)
2. Add to `.env`: `ALPHA_VANTAGE_API_KEY=your_key_here`
3. In `config.py`: set `SIMULATION_MODE = False`

---

## Alert Delivery

### Telegram

1. Create a bot via [@BotFather](https://t.me/BotFather) and copy the token
2. Get your chat ID via [@userinfobot](https://t.me/userinfobot)
3. Add to `.env`:
   ```
   TELEGRAM_BOT_TOKEN=your_token
   TELEGRAM_CHAT_ID=your_chat_id
   ```
4. In `config.py`: `ALERT_CHANNELS = ["console", "telegram"]`

### Discord

1. In your Discord server: **Settings → Integrations → Webhooks → New Webhook**
2. Copy the webhook URL
3. Add to `.env`: `DISCORD_WEBHOOK_URL=your_webhook_url`
4. In `config.py`: `ALERT_CHANNELS = ["console", "discord"]`

---

## Strategy Overview

The bot follows a 7-step discretionary framework — no black boxes, all logic is rule-based and commented.

```
4H Bias
  └─ Bullish / Bearish / Neutral
       └─ Key Zone Identified
            └─ Liquidity Sweep Detected
                 └─ Break of Structure Confirmed
                      └─ Retest Holds
                           └─ RR ≥ 1.8
                                └─ No News Conflict
                                     └─ ALERT SENT ✓
```

### Confidence Scoring (100 pts)

| Condition | Points |
|---|---|
| 4H + 1H alignment | 20 |
| Strong zone quality | 20 |
| Liquidity sweep confirmed | 15 |
| Break of structure + retest | 20 |
| Prime session (London/NY) | 10 |
| No major news conflict | 10 |
| RR ≥ 2.0 bonus | 5 |

**Alert grades:** A (85–100) · B (70–84) · No alert (< 70)

---

## Sample Alert

```
╔══════════════════════════════════════════════╗
  EUR/USD ALERT — BUY SETUP
╚══════════════════════════════════════════════╝

  Bias:        Bullish
  Confidence:  82/100  [████████░░]
  Session:     London
  Setup Type:  Liquidity Sweep Reversal
  Time (UTC):  2026-03-22 09:14

──────────────────────────────────────────────
  REASON
──────────────────────────────────────────────
  • 4H and 1H both bullish — timeframe alignment confirmed
  • Price reacting at 1H demand (1.08142–1.08210)
  • Liquidity sweep of recent swing detected (12.4 pip rejection wick)
  • 15M break of structure above 1.08185
  • Retest of broken level held — confirmation confirmed
  • Active London session
  • No major news events in proximity

──────────────────────────────────────────────
  LEVELS
──────────────────────────────────────────────
  Entry Zone:  1.08230 – 1.08260
  Stop Loss:   1.08105
  TP1:         1.08420
  TP2:         1.08650
  RR:          1:2.1

──────────────────────────────────────────────
  INVALIDATION
──────────────────────────────────────────────
  • Price closes below 1.08105 (stop level)
  • Bearish BOS on 15M without recovery
  • Zone 1.08142 broken to the downside

──────────────────────────────────────────────
  TRADE QUALITY:  B-GRADE
──────────────────────────────────────────────
```

---

## Trade Journal

Every alert is logged automatically. Update outcomes after you review them:

```python
from journal import update_outcome

# Log the result of alert ID 12
update_outcome(alert_id=12, outcome="win_tp1", outcome_pips=19.0, notes="Clean sweep entry")
```

View stats:

```bash
python main.py --mode stats
```

---

## Roadmap

- [ ] FVG (Fair Value Gap) detection
- [ ] Order block identification
- [ ] Multi-pair support (GBP/USD, USD/JPY)
- [ ] Historical backtesting engine
- [ ] Web dashboard (FastAPI + React)
- [ ] Telegram inline buttons for outcome logging
- [ ] Discord rich embeds with mini price chart
- [ ] Alert deduplication across cycles
- [ ] Weekly performance email report

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). PRs welcome against the `dev` branch.

**Note:** Auto-execution and broker order placement will never be part of this project by design.

---

## License

[MIT](LICENSE)
