# Contributing

Contributions are welcome! Please follow these guidelines.

## Getting Started

```bash
git clone https://github.com/YOUR_USERNAME/eurusd-alert-bot.git
cd eurusd-alert-bot
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
```

## Branching

- `main` — stable, production-ready code
- `dev` — active development
- Feature branches: `feature/your-feature-name`
- Bug fixes: `fix/short-description`

## Submitting Changes

1. Fork the repo and create your branch from `dev`
2. Make your changes with clear, commented code
3. Test in simulation mode: `python main.py --mode once --verbose`
4. Open a pull request against `dev` with a clear description

## Code Style

- Follow PEP 8
- Add docstrings to all public functions
- Keep strategy logic transparent and rule-based
- Add comments explaining *why*, not just *what*

## Ideas for Contribution

- Additional setup types (FVG, order blocks)
- More data feed integrations
- Backtesting engine
- Web dashboard
- Additional currency pairs

## Important

**Never add auto-execution or broker order placement.** This project is alerts-only by design.
