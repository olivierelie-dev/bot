# Changelog

All notable changes to this project will be documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.0.0] — 2026-03-22

### Added
- Initial Version 1 release
- Simulation mode with realistic synthetic EUR/USD candle generation
- Live data support via Alpha Vantage (free tier)
- EMA 20/50, trend direction, candle classification
- Swing high/low detection with configurable lookback
- Break of Structure (BOS) and retest logic
- Supply/demand zone detection from impulse candles
- Key level tracking: Previous Day High/Low, session highs/lows, psychological levels
- Liquidity sweep detection with wick-size validation
- London (08–11 UTC) and New York (13–16 UTC) session filters
- High-impact news calendar filter with hard block and soft penalty modes
- 100-point confidence scoring engine with configurable weights
- A/B grade alert thresholds (85+ = A, 70–84 = B)
- Risk:Reward calculator with min 1.8R filter, 2.0R bonus
- Stop loss placement: below sweep low / demand zone + buffer
- TP1 and TP2 levels with structural snap logic
- Formatted alert output with entry zone, SL, TP1, TP2, RR, reasons, invalidations
- Telegram and Discord webhook delivery
- Console output mode for development
- SQLite trade journal with outcome tracking
- CLI interface: `--mode run`, `--mode once`, `--mode stats`
- Dual console + file logging
- `.env.example`, `.gitignore`, `requirements.txt`

### Security
- No broker credentials or auto-execution code included
- All secrets managed via `.env` (excluded from version control)
